Put your mkcert-generated certificate here as exactly these two files:

  cert.pem
  key.pem

The dev server (dev-server/server.js) automatically detects both files on
startup and switches from HTTP to HTTPS mode — no config changes needed.

See the root README.md, section "5. Local HTTPS with mkcert", for the full
step-by-step (including trusting the cert on your Android phone).

This folder is empty by default, which is correct — the dev server runs in
plain HTTP mode until you put real certs here.
