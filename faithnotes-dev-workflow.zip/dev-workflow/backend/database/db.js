// database/db.js
// SQLite database connection + schema initialization.
// Uses better-sqlite3 (synchronous, no native-binding surprises across platforms).
// Swap this file out later to point at Postgres/MySQL — nothing outside this
// module needs to know which database engine is behind it, as long as the
// same function names (get/all/run helpers) keep working the same way.

const path = require('path');
const fs = require('fs');
const Database = require('better-sqlite3');

const DB_DIR = path.join(__dirname);
const DB_PATH = process.env.DB_PATH || path.join(DB_DIR, 'faithnotes.sqlite');

if (!fs.existsSync(DB_DIR)) fs.mkdirSync(DB_DIR, { recursive: true });

const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

// ---------- Schema ----------
db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id            TEXT PRIMARY KEY,
  name          TEXT NOT NULL,
  email         TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  church        TEXT DEFAULT '',
  location      TEXT DEFAULT '',
  phone         TEXT DEFAULT '',
  plan          TEXT DEFAULT 'Free',
  created_at    TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at    TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS recordings (
  id                TEXT PRIMARY KEY,
  user_id           TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  local_id          TEXT,
  title             TEXT NOT NULL DEFAULT 'Untitled Sermon',
  preacher          TEXT DEFAULT '',
  church            TEXT DEFAULT '',
  location          TEXT DEFAULT '',
  sermon_date       TEXT DEFAULT '',
  category          TEXT DEFAULT '',
  filename          TEXT NOT NULL,
  filepath          TEXT NOT NULL,
  mime_type         TEXT DEFAULT '',
  file_size         INTEGER DEFAULT 0,
  duration_sec      INTEGER DEFAULT 0,
  codec             TEXT DEFAULT '',
  sample_rate       INTEGER DEFAULT 0,
  channels          INTEGER DEFAULT 0,
  bitrate           INTEGER DEFAULT 0,
  device            TEXT DEFAULT '',
  browser           TEXT DEFAULT '',
  avg_input_level   REAL DEFAULT 0,
  peak_input_level  REAL DEFAULT 0,
  noise_label       TEXT DEFAULT '',
  session_id        TEXT DEFAULT '',
  waveform_metadata TEXT DEFAULT '',
  transcript        TEXT DEFAULT '',
  created_at        TEXT NOT NULL DEFAULT (datetime('now')),
  synced_at         TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_recordings_user ON recordings(user_id);
CREATE INDEX IF NOT EXISTS idx_recordings_local_id ON recordings(local_id);

CREATE TABLE IF NOT EXISTS logs (
  id          TEXT PRIMARY KEY,
  user_id     TEXT REFERENCES users(id) ON DELETE CASCADE,
  session_id  TEXT DEFAULT '',
  type        TEXT NOT NULL,
  message     TEXT NOT NULL,
  browser     TEXT DEFAULT '',
  meta        TEXT DEFAULT '',
  created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_logs_user ON logs(user_id);
CREATE INDEX IF NOT EXISTS idx_logs_type ON logs(type);

CREATE TABLE IF NOT EXISTS sync_events (
  id          TEXT PRIMARY KEY,
  user_id     TEXT REFERENCES users(id) ON DELETE CASCADE,
  local_id    TEXT NOT NULL,
  status      TEXT NOT NULL DEFAULT 'synced',
  created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_sync_events_user ON sync_events(user_id);
`);

module.exports = db;
