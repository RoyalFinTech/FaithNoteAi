// middleware/upload.js
// Handles audio file uploads with strict validation:
//  - only audio mimetypes accepted
//  - filenames sanitized and replaced with a generated UUID-based name
//    (the client's original filename is never trusted or used on disk)
//  - hard size cap enforced

const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { v4: uuidv4 } = require('uuid');

const UPLOAD_DIR = path.join(__dirname, '..', 'uploads');
if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR, { recursive: true });

const ALLOWED_MIME_TYPES = new Set([
  'audio/webm',
  'audio/webm;codecs=opus',
  'audio/ogg',
  'audio/ogg;codecs=opus',
  'audio/mp4',
  'audio/mp4;codecs=mp4a.40.2',
  'audio/mpeg',
  'audio/mp3',
  'audio/wav',
  'audio/x-wav',
  'audio/wave'
]);

const EXT_BY_MIME = {
  'audio/webm': '.webm',
  'audio/ogg': '.ogg',
  'audio/mp4': '.m4a',
  'audio/mpeg': '.mp3',
  'audio/mp3': '.mp3',
  'audio/wav': '.wav',
  'audio/x-wav': '.wav',
  'audio/wave': '.wav'
};

function baseMime(mime) {
  return (mime || '').split(';')[0].trim().toLowerCase();
}

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, UPLOAD_DIR),
  filename: (req, file, cb) => {
    // Never trust the client-supplied filename — generate our own.
    const ext = EXT_BY_MIME[baseMime(file.mimetype)] || '.audio';
    const safeName = `${uuidv4()}${ext}`;
    cb(null, safeName);
  }
});

function fileFilter(req, file, cb) {
  const mime = baseMime(file.mimetype);
  if (!ALLOWED_MIME_TYPES.has(mime) && !ALLOWED_MIME_TYPES.has(file.mimetype)) {
    return cb(new Error('UNSUPPORTED_FILE_TYPE'));
  }
  cb(null, true);
}

const MAX_UPLOAD_BYTES = parseInt(process.env.MAX_UPLOAD_MB || '100', 10) * 1024 * 1024;

const upload = multer({
  storage,
  fileFilter,
  limits: { fileSize: MAX_UPLOAD_BYTES, files: 1 }
});

module.exports = { upload, UPLOAD_DIR, MAX_UPLOAD_BYTES };
