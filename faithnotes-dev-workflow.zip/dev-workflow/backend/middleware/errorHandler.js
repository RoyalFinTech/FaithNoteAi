// middleware/errorHandler.js
const multer = require('multer');

function notFoundHandler(req, res) {
  res.status(404).json({ error: 'NotFound', message: `No route: ${req.method} ${req.originalUrl}` });
}

// `next` is required in the signature below even though it's unused in the
// body: Express detects error-handling middleware by counting declared
// parameters (arity). A 3-arg function here would be treated as regular
// middleware and would never receive errors.
// eslint-disable-next-line no-unused-vars
function errorHandler(err, req, res, next) {
  if (err instanceof multer.MulterError) {
    if (err.code === 'LIMIT_FILE_SIZE') {
      return res.status(413).json({ error: 'PayloadTooLarge', message: 'The audio file exceeds the maximum allowed upload size.' });
    }
    return res.status(400).json({ error: 'UploadError', message: err.message });
  }
  if (err && err.message === 'UNSUPPORTED_FILE_TYPE') {
    return res.status(415).json({ error: 'UnsupportedMediaType', message: 'Only audio files (webm, ogg, mp4/m4a, mp3, wav) are accepted.' });
  }
  if (err && err.type === 'entity.parse.failed') {
    return res.status(400).json({ error: 'ValidationError', message: 'Request body is not valid JSON.' });
  }
  console.error('[FaithNotes:Backend] Unhandled error:', err);
  res.status(err.status || 500).json({ error: 'ServerError', message: 'Something went wrong on the server.' });
}

module.exports = { notFoundHandler, errorHandler };
