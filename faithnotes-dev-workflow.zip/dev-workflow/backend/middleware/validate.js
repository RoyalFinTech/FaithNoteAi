// middleware/validate.js
const { validationResult } = require('express-validator');

module.exports = function validate(req, res, next) {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'ValidationError',
      message: errors.array().map(e => e.msg).join('; '),
      fields: errors.array().map(e => ({ field: e.path, message: e.msg }))
    });
  }
  next();
};
