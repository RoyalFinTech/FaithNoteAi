// middleware/auth.js
// Verifies a Bearer JWT on protected routes and attaches req.user.

const jwt = require('jsonwebtoken');

function requireAuth(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;

  if (!token) {
    return res.status(401).json({ error: 'Unauthorized', message: 'Missing bearer token. Log in and include the returned token as: Authorization: Bearer <token>' });
  }

  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    req.user = { id: payload.sub, email: payload.email };
    next();
  } catch (err) {
    const message = err.name === 'TokenExpiredError'
      ? 'Session expired. Please log in again.'
      : 'Invalid or malformed token.';
    return res.status(401).json({ error: 'Unauthorized', message });
  }
}

// Like requireAuth, but doesn't reject the request if no/invalid token is present —
// used on routes (like log ingestion) that should work whether or not the user is logged in.
function optionalAuth(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) { req.user = null; return next(); }
  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    req.user = { id: payload.sub, email: payload.email };
  } catch (err) {
    req.user = null;
  }
  next();
}

module.exports = { requireAuth, optionalAuth };
