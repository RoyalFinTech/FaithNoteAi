// middleware/rateLimiter.js
const rateLimit = require('express-rate-limit');

// Generous general API limiter
const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 300,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'TooManyRequests', message: 'Too many requests. Please slow down and try again shortly.' }
});

// Stricter limiter for auth endpoints (brute-force protection)
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 20,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'TooManyRequests', message: 'Too many authentication attempts. Please wait a few minutes and try again.' }
});

// Slightly stricter limiter for uploads (large payloads, disk usage)
const uploadLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 60,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'TooManyRequests', message: 'Too many uploads in a short time. Please wait a moment and try again.' }
});

module.exports = { apiLimiter, authLimiter, uploadLimiter };
