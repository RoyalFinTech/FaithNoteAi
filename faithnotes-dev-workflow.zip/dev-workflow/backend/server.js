// server.js
// FaithNotes AI backend — Express + Socket.IO + SQLite
// Run with: node server.js  (or npm start)

require('dotenv').config();

const express = require('express');
const http = require('http');
const path = require('path');
const cors = require('cors');
const helmet = require('helmet');
const compression = require('compression');
const morgan = require('morgan');
const { Server: SocketIOServer } = require('socket.io');
const jwt = require('jsonwebtoken');

if (!process.env.JWT_SECRET) {
  console.error('[FaithNotes:Backend] Missing JWT_SECRET in .env — refusing to start with an insecure default.');
  console.error('[FaithNotes:Backend] Copy .env.example to .env and set a real JWT_SECRET, then restart.');
  process.exit(1);
}

const { apiLimiter } = require('./middleware/rateLimiter');
const { notFoundHandler, errorHandler } = require('./middleware/errorHandler');
const db = require('./database/db'); // same cached singleton every controller uses — needed here only to close it on shutdown

const authRoutes = require('./routes/auth');
const recordingsRoutes = require('./routes/recordings');
const syncRoutes = require('./routes/sync');
const logsRoutes = require('./routes/logs');
const statusRoutes = require('./routes/status');

const app = express();
const server = http.createServer(app);

// ---------- Security & core middleware ----------
app.use(helmet({
  crossOriginResourcePolicy: { policy: 'cross-origin' } // allow the phone/browser to load /uploads audio directly
}));

// Helmet does not set Permissions-Policy by default (it was removed from
// Helmet's core middleware set — browser support and the exact feature list
// are still evolving, so Helmet leaves the actual values to the app). This
// API server has no legitimate use for any of these browser features, so
// everything is disabled.
app.use((req, res, next) => {
  res.setHeader('Permissions-Policy', 'geolocation=(), microphone=(), camera=(), payment=(), usb=(), interest-cohort=()');
  next();
});

app.use(compression());
app.use(morgan(process.env.NODE_ENV === 'production' ? 'combined' : 'dev'));

// CORS: this backend is built for LOCAL TESTING (your PC + your phone on the
// same Wi-Fi), reached by opening the HTML file directly (file:// origin) or
// from a dev server. That means the incoming Origin header is often "null"
// or unpredictable, so we reflect whatever Origin was sent rather than
// hard-coding one. For a real production deployment behind a real domain,
// replace this with an explicit allow-list — see README "Production
// Deployment" section.
// credentials is deliberately false: this API has no cookie-based session
// anywhere (auth is Bearer-token-only, attached via an explicit
// Authorization header the frontend's own JS sets) — there is nothing for
// the browser to send automatically, so enabling credentialed CORS would
// only widen the attack surface for no functional benefit.
app.use(cors({
  origin: (origin, callback) => callback(null, true),
  credentials: false
}));

app.use(express.json({ limit: '2mb' }));
app.use(express.urlencoded({ extended: true }));
app.use('/api', apiLimiter);

// Serve uploaded audio files statically so the frontend can play/download them directly
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// ---------- Socket.IO (real-time sync/status push) ----------
const io = new SocketIOServer(server, { cors: { origin: '*' } });
app.set('io', io);

io.use((socket, next) => {
  const token = socket.handshake.auth && socket.handshake.auth.token;
  if (!token) return next(); // allow anonymous connection for public status updates
  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    socket.userId = payload.sub;
  } catch (e) { /* ignore invalid token, connection stays anonymous */ }
  next();
});
io.on('connection', (socket) => {
  if (socket.userId) socket.join(`user:${socket.userId}`);
  console.log('[FaithNotes:Backend] Socket connected', socket.id, socket.userId ? `(user ${socket.userId})` : '(anonymous)');
  socket.on('disconnect', () => console.log('[FaithNotes:Backend] Socket disconnected', socket.id));
});

// ---------- Routes ----------
app.get('/', (req, res) => {
  res.json({ name: 'FaithNotes AI Backend', status: 'running', docs: '/api/status' });
});

// Every route below can return user-specific or otherwise sensitive data
// (profile fields, recording metadata, sync/log history) — tell browsers
// and any intermediary caches never to store these responses. /api/status
// (public, non-sensitive) and /uploads (audio files, fine to cache) are
// deliberately excluded from this.
const noStore = (req, res, next) => { res.setHeader('Cache-Control', 'no-store'); next(); };
app.use('/api/status', statusRoutes);
app.use('/api', noStore, authRoutes);
app.use('/api/recordings', noStore, recordingsRoutes);
app.use('/api/sync', noStore, syncRoutes);
app.use('/api/logs', noStore, logsRoutes);

app.use(notFoundHandler);
app.use(errorHandler);

// ---------- Start ----------
const PORT = process.env.PORT || 3000;
const HOST = process.env.HOST || '0.0.0.0'; // 0.0.0.0 so your phone on the same Wi-Fi can reach it

server.listen(PORT, HOST, () => {
  console.log('==========================================================');
  console.log(' FaithNotes AI Backend');
  console.log('==========================================================');
  console.log(` Local:    http://localhost:${PORT}`);
  console.log(` Network:  http://<your-computer-ip>:${PORT}   (use this from your phone)`);
  console.log(` Status:   http://localhost:${PORT}/api/status`);
  console.log('==========================================================');
});

// ---------- Graceful shutdown ----------
// On SIGTERM/SIGINT (Ctrl+C, `docker stop`, a process manager restart, etc.),
// stop accepting new connections and let in-flight requests finish instead
// of cutting them off mid-response, then close Socket.IO and the database
// cleanly. A safety timeout forces exit if something (e.g. a long-lived
// socket) never closes on its own, so shutdown can never hang forever.
let shuttingDown = false;
function gracefulShutdown(signal) {
  if (shuttingDown) return;
  shuttingDown = true;
  console.log(`\n[FaithNotes:Backend] Received ${signal}, shutting down gracefully…`);

  const forceExitTimer = setTimeout(() => {
    console.error('[FaithNotes:Backend] Shutdown taking too long — forcing exit.');
    process.exit(1);
  }, 10000);
  forceExitTimer.unref(); // don't let this timer itself keep the process alive if everything else already closed

  // Both close operations are async and run concurrently. Exiting must wait
  // for BOTH callbacks, not just whichever happens to finish first — an
  // earlier version of this function called process.exit() as soon as
  // server.close() finished, which reliably won that race and meant
  // io.close()'s callback never got a chance to run at all.
  let pending = 2;
  let hadError = false;
  function finishOne(label, err) {
    if (err) { hadError = true; console.error(`[FaithNotes:Backend] Error while closing ${label}:`, err.message); }
    else { console.log(`[FaithNotes:Backend] ${label} closed.`); }
    pending--;
    if (pending === 0) {
      try {
        db.close();
        console.log('[FaithNotes:Backend] Database connection closed.');
      } catch (dbErr) {
        hadError = true;
        console.error('[FaithNotes:Backend] Error while closing database:', dbErr.message);
      }
      clearTimeout(forceExitTimer);
      process.exit(hadError ? 1 : 0);
    }
  }

  io.close(() => finishOne('Socket.IO'));
  server.close((err) => finishOne('HTTP server', err));
}
process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));

module.exports = { app, server };
