// test/api.test.js
// Integration tests for the FaithNotes backend, using Node's built-in
// test runner (node:test) and built-in fetch — zero new npm dependencies,
// matching the project's existing "no framework migrations" architecture.
//
// Run with: npm test  (see package.json)
//
// These tests start a real instance of the server (server.js) on a test
// port, against a throwaway SQLite database file, and make real HTTP
// requests against it — the same endpoints a real client would call.

const test = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const fs = require('node:fs');

const TEST_DB_PATH = path.join(__dirname, 'test.sqlite');
const TEST_PORT = 3999;
const BASE_URL = `http://127.0.0.1:${TEST_PORT}`;

// Clean up any leftover test DB from a previous run before we start —
// each test run gets a fresh database.
for (const suffix of ['', '-shm', '-wal']) {
  const p = TEST_DB_PATH + suffix;
  if (fs.existsSync(p)) fs.unlinkSync(p);
}

process.env.JWT_SECRET = 'test-secret-not-for-real-use-' + Date.now();
process.env.PORT = String(TEST_PORT);
process.env.HOST = '127.0.0.1';
process.env.DB_PATH = TEST_DB_PATH;
process.env.NODE_ENV = 'test';

const { server } = require('../server');

test.after(async () => {
  await new Promise((resolve) => server.close(resolve));
  for (const suffix of ['', '-shm', '-wal']) {
    const p = TEST_DB_PATH + suffix;
    if (fs.existsSync(p)) fs.unlinkSync(p);
  }
});

function uniqueEmail(prefix) {
  return `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}@test.dev`;
}

// ---------- Status ----------
test('GET /api/status returns server health info', async () => {
  const res = await fetch(`${BASE_URL}/api/status`);
  assert.equal(res.status, 200);
  const body = await res.json();
  assert.equal(body.serverOnline, true);
  assert.equal(body.databaseConnected, true);
  assert.equal(typeof body.apiVersion, 'string');
});

// ---------- Auth ----------
test('POST /api/register creates a new account and returns a token', async () => {
  const email = uniqueEmail('register');
  const res = await fetch(`${BASE_URL}/api/register`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name: 'Test User', email, password: 'testpass123' })
  });
  assert.equal(res.status, 201);
  const body = await res.json();
  assert.equal(typeof body.token, 'string');
  assert.equal(body.user.email, email);
});

test('POST /api/register rejects a duplicate email with 409', async () => {
  const email = uniqueEmail('dup');
  const payload = { name: 'Dup User', email, password: 'testpass123' };
  const first = await fetch(`${BASE_URL}/api/register`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
  assert.equal(first.status, 201);
  const second = await fetch(`${BASE_URL}/api/register`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
  assert.equal(second.status, 409);
});

test('POST /api/register rejects a password under 8 characters', async () => {
  const res = await fetch(`${BASE_URL}/api/register`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name: 'Weak', email: uniqueEmail('weak'), password: '123' })
  });
  assert.equal(res.status, 400);
});

test('POST /api/login succeeds with correct credentials', async () => {
  const email = uniqueEmail('login');
  await fetch(`${BASE_URL}/api/register`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name: 'Login Test', email, password: 'testpass123' }) });
  const res = await fetch(`${BASE_URL}/api/login`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email, password: 'testpass123' }) });
  assert.equal(res.status, 200);
  const body = await res.json();
  assert.equal(typeof body.token, 'string');
});

test('POST /api/login rejects an incorrect password with 401', async () => {
  const email = uniqueEmail('wrongpw');
  await fetch(`${BASE_URL}/api/register`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name: 'Wrong PW', email, password: 'testpass123' }) });
  const res = await fetch(`${BASE_URL}/api/login`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email, password: 'not-the-password' }) });
  assert.equal(res.status, 401);
});

test('GET /api/profile requires authentication (401 with no token)', async () => {
  const res = await fetch(`${BASE_URL}/api/profile`);
  assert.equal(res.status, 401);
});

test('GET /api/profile returns the correct user with a valid token', async () => {
  const email = uniqueEmail('profile');
  const reg = await fetch(`${BASE_URL}/api/register`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name: 'Profile Test', email, password: 'testpass123' }) });
  const { token } = await reg.json();
  const res = await fetch(`${BASE_URL}/api/profile`, { headers: { Authorization: `Bearer ${token}` } });
  assert.equal(res.status, 200);
  const body = await res.json();
  assert.equal(body.user.email, email);
});

// ---------- Recordings: ownership / IDOR protection ----------
test('a user cannot access another user\'s recording by ID', async () => {
  // User A registers and uploads nothing (no audio handling needed for this
  // check) — we only need a recording to exist under User A, then confirm
  // User B's token can't read it via GET /api/recordings/:id.
  const emailA = uniqueEmail('userA');
  const emailB = uniqueEmail('userB');
  const regA = await fetch(`${BASE_URL}/api/register`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name: 'User A', email: emailA, password: 'testpass123' }) });
  const { token: tokenA } = await regA.json();
  const regB = await fetch(`${BASE_URL}/api/register`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name: 'User B', email: emailB, password: 'testpass123' }) });
  const { token: tokenB } = await regB.json();

  // Upload a tiny fake audio file as User A
  const form = new FormData();
  const blob = new Blob([new Uint8Array(2000)], { type: 'audio/webm' });
  form.append('audio', blob, 'test.webm');
  form.append('title', 'User A Private Sermon');
  const uploadRes = await fetch(`${BASE_URL}/api/recordings/upload`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${tokenA}` },
    body: form
  });
  assert.equal(uploadRes.status, 201);
  const { recording } = await uploadRes.json();

  // User A can read it
  const asA = await fetch(`${BASE_URL}/api/recordings/${recording.id}`, { headers: { Authorization: `Bearer ${tokenA}` } });
  assert.equal(asA.status, 200);

  // User B cannot — must be 404 (not 403, to avoid confirming existence — matches the controller's actual behavior)
  const asB = await fetch(`${BASE_URL}/api/recordings/${recording.id}`, { headers: { Authorization: `Bearer ${tokenB}` } });
  assert.equal(asB.status, 404);

  // User B cannot delete it either
  const deleteAsB = await fetch(`${BASE_URL}/api/recordings/${recording.id}`, { method: 'DELETE', headers: { Authorization: `Bearer ${tokenB}` } });
  assert.equal(deleteAsB.status, 404);

  // ...but User A can
  const deleteAsA = await fetch(`${BASE_URL}/api/recordings/${recording.id}`, { method: 'DELETE', headers: { Authorization: `Bearer ${tokenA}` } });
  assert.equal(deleteAsA.status, 200);
});

test('POST /api/recordings/upload rejects a non-audio file with 415', async () => {
  const email = uniqueEmail('badupload');
  const reg = await fetch(`${BASE_URL}/api/register`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name: 'Bad Upload', email, password: 'testpass123' }) });
  const { token } = await reg.json();
  const form = new FormData();
  form.append('audio', new Blob(['not audio'], { type: 'text/plain' }), 'note.txt');
  const res = await fetch(`${BASE_URL}/api/recordings/upload`, { method: 'POST', headers: { Authorization: `Bearer ${token}` }, body: form });
  assert.equal(res.status, 415);
});

test('GET /api/recordings only returns the authenticated user\'s own recordings', async () => {
  const email = uniqueEmail('listtest');
  const reg = await fetch(`${BASE_URL}/api/register`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name: 'List Test', email, password: 'testpass123' }) });
  const { token } = await reg.json();
  const res = await fetch(`${BASE_URL}/api/recordings`, { headers: { Authorization: `Bearer ${token}` } });
  assert.equal(res.status, 200);
  const body = await res.json();
  assert.equal(Array.isArray(body.recordings), true);
  assert.equal(body.recordings.length, 0); // brand new user, no uploads yet
});

// ---------- Validation / error shape ----------
test('malformed JSON body returns a clear 400, not a generic 500', async () => {
  const res = await fetch(`${BASE_URL}/api/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: '{not valid json'
  });
  assert.equal(res.status, 400);
  const body = await res.json();
  assert.equal(body.error, 'ValidationError');
});

test('unknown route returns a JSON 404, not an HTML error page', async () => {
  const res = await fetch(`${BASE_URL}/api/this-route-does-not-exist`);
  assert.equal(res.status, 404);
  const contentType = res.headers.get('content-type') || '';
  assert.match(contentType, /application\/json/);
});
