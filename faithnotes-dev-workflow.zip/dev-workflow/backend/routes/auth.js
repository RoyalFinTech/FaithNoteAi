// routes/auth.js
const express = require('express');
const router = express.Router();
const { body } = require('express-validator');
const validate = require('../middleware/validate');
const { requireAuth } = require('../middleware/auth');
const { authLimiter } = require('../middleware/rateLimiter');
const authController = require('../controllers/authController');

router.post('/register', authLimiter, [
  body('name').trim().notEmpty().withMessage('name is required'),
  body('email').trim().isEmail().withMessage('a valid email is required'),
  body('password').isLength({ min: 8 }).withMessage('password must be at least 8 characters')
], validate, authController.register);

router.post('/login', authLimiter, [
  body('email').trim().isEmail().withMessage('a valid email is required'),
  body('password').notEmpty().withMessage('password is required')
], validate, authController.login);

router.post('/logout', requireAuth, authController.logout);
router.get('/profile', requireAuth, authController.getProfile);
router.put('/profile', requireAuth, [
  body('name').optional().trim().isLength({ min: 1 }),
  body('phone').optional().trim(),
  body('church').optional().trim(),
  body('location').optional().trim()
], validate, authController.updateProfile);

module.exports = router;
