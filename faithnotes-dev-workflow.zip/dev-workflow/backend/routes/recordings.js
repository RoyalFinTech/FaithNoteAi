// routes/recordings.js
const express = require('express');
const router = express.Router();
const { requireAuth } = require('../middleware/auth');
const { upload } = require('../middleware/upload');
const { uploadLimiter } = require('../middleware/rateLimiter');
const recordingsController = require('../controllers/recordingsController');

router.post('/upload', requireAuth, uploadLimiter, upload.single('audio'), recordingsController.uploadRecording);
router.get('/', requireAuth, recordingsController.listRecordings);
router.get('/:id', requireAuth, recordingsController.getRecording);
router.delete('/:id', requireAuth, recordingsController.deleteRecording);

module.exports = router;
