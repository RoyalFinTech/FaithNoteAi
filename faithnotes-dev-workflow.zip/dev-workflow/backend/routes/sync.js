// routes/sync.js
const express = require('express');
const router = express.Router();
const { requireAuth } = require('../middleware/auth');
const syncController = require('../controllers/syncController');

router.post('/', requireAuth, syncController.syncAcknowledge);
router.get('/status', requireAuth, syncController.syncStatus);

module.exports = router;
