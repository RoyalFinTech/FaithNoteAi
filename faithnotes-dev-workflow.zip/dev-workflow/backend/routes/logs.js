// routes/logs.js
const express = require('express');
const router = express.Router();
const { optionalAuth } = require('../middleware/auth');
const logsController = require('../controllers/logsController');

router.post('/', optionalAuth, logsController.createLog);
router.get('/', optionalAuth, logsController.listLogs);

module.exports = router;
