# Faithnotes AI — Backend

A real, working Node.js/Express/Socket.IO/SQLite backend for the Faithnotes AI
recording app: authentication, recording uploads, offline sync, structured
logging, and a status endpoint.

This backend has been tested end-to-end in development (register → login →
profile → upload → list → get → delete, validation errors, file-type
rejection, security headers) — see "What's been tested" below.

---

## 1. Setup

**Requirements:** Node.js 18+ (uses `better-sqlite3`, which installs a
prebuilt binary for most platforms — no separate SQLite install needed).

```bash
cd backend
npm install
cp .env.example .env
```

Open `.env` and set a real `JWT_SECRET`. Generate one with:

```bash
node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"
```

Paste the output as the value of `JWT_SECRET` in `.env`. **Do not skip this
step** — the server refuses to start without a real secret set.

Start it:

```bash
npm start
```

You should see:

```
==========================================================
 FaithNotes AI Backend
==========================================================
 Local:    http://localhost:3000
 Network:  http://<your-computer-ip>:3000   (use this from your phone)
 Status:   http://localhost:3000/api/status
==========================================================
```

Confirm it's alive:

```bash
curl http://localhost:3000/api/status
```

The SQLite database file is created automatically at
`backend/database/faithnotes.sqlite` on first run — nothing to set up by hand.
Uploaded audio files land in `backend/uploads/`.

---

## 2. Connecting the frontend

Open the frontend HTML file's Settings screen → look for **Backend Server**
and enter your computer's local network address, e.g. `http://192.168.1.100:3000`.
Find your computer's IP with:

- **Windows:** `ipconfig` → look for "IPv4 Address" under your Wi-Fi adapter
- **Mac:** `ipconfig getifaddr en0` (or `en1`)
- **Linux:** `hostname -I`

This is also settable as a one-line default in the HTML file itself, at the
top of the `<script>` block:

```js
const API_BASE_DEFAULT = "http://192.168.1.100:3000/api";
```

Every API call in the frontend goes through this one constant (or the
Settings override, which takes priority) — there's nowhere else to edit.

---

## 3. Testing on Android Chrome

If this `backend/` folder is inside the full `faithnotes-dev-workflow`
package, **use the root `README.md` there** — it covers running this backend
together with the dedicated frontend dev server, finding your LAN IP, and
the two ways to get microphone access working on Android over your local
network (a Chrome dev flag, or local HTTPS via mkcert). That's the
supported, tested path and this section won't repeat it.

If you only have this `backend/` folder on its own: you still need
something serving the frontend HTML over `http://` or `https://` — opening
it via `file://` (double-clicking the file, or a Downloads-folder link)
won't work, since the browser never even requests microphone permission on
that origin. The `dev-server/` folder from the full package is a
zero-dependency static server built exactly for this; grab it separately if
you don't have the rest of the package.

---

## 4. API Documentation

All endpoints are prefixed with `/api`. Authenticated endpoints require:

```
Authorization: Bearer <token>
```

### Auth

| Method | Path | Auth | Body | Notes |
|---|---|---|---|---|
| POST | `/api/register` | — | `{ name, email, password, church?, location?, phone? }` | Returns `{ token, user }`. Password min 8 chars. |
| POST | `/api/login` | — | `{ email, password }` | Returns `{ token, user }`. |
| POST | `/api/logout` | ✓ | — | Stateless JWT — tells the client to discard the token (see note below). |
| GET | `/api/profile` | ✓ | — | Returns `{ user }`. |
| PUT | `/api/profile` | ✓ | `{ name?, church?, location?, phone? }` | Returns updated `{ user }`. |

> **JWT logout note:** JWTs are stateless by design — there's no server-side
> session to destroy without adding a token blacklist/store, which this
> local-testing backend intentionally doesn't add (see "Known simplifications"
> below). `/api/logout` exists as a clean endpoint the frontend can call, but
> the actual "log out" action is the client deleting its stored token.

### Recordings

| Method | Path | Auth | Body | Notes |
|---|---|---|---|---|
| POST | `/api/recordings/upload` | ✓ | multipart/form-data, field `audio` = file, plus metadata fields (see below) | Returns `{ recording }`. Max size set by `MAX_UPLOAD_MB` in `.env` (default 100MB). |
| GET | `/api/recordings` | ✓ | — | Returns `{ recordings: [...], count }` for the logged-in user, newest first. |
| GET | `/api/recordings/:id` | ✓ | — | Returns `{ recording }`. 404 if not found or not yours. |
| DELETE | `/api/recordings/:id` | ✓ | — | Deletes the DB row and the audio file from disk. |

**Upload metadata fields** (all optional except the file itself):
`localId, title, preacher, church, location, date, category, durationSec,
codec, sampleRate, channels, bitrate, device, browser, avgInputLevel,
peakInputLevel, noiseLabel, sessionId, waveformMetadata (JSON string),
transcript`

Accepted audio types: `audio/webm`, `audio/ogg`, `audio/mp4`, `audio/mpeg`,
`audio/wav` (and common codec-suffixed variants like
`audio/webm;codecs=opus`). Anything else is rejected with `415`.

### Sync

| Method | Path | Auth | Body | Notes |
|---|---|---|---|---|
| POST | `/api/sync` | ✓ | `{ localId, status? }` | Records a sync event for a local queue item (see design note in code). |
| GET | `/api/sync/status` | ✓ | — | Server-side sync health: total recordings, last synced time, recent sync events. |

> The server has no visibility into what's still sitting in a phone's
> IndexedDB queue that hasn't been sent yet — `GET /api/sync/status` reports
> what the *server* knows; the frontend combines that with its own local
> queue length for the full picture.

### Logs

| Method | Path | Auth | Body | Notes |
|---|---|---|---|---|
| POST | `/api/logs` | optional | one log object or an array: `{ sessionId?, type, message, browser?, meta? }` | `type` is one of `warning, clipping, silence, mic_change, recovery, error, session, info`. Works logged-out too (user_id stored as null). |
| GET | `/api/logs` | ✓ | query: `?type=&sessionId=&limit=` | Returns the logged-in user's own logs. |

### Status

| Method | Path | Auth | Notes |
|---|---|---|---|
| GET | `/api/status` | — | `{ serverOnline, databaseConnected, uploadQueue, currentTime, uptimeSec, storageUsedBytes, storageUsedMB, totalRecordings, apiVersion }`. `uploadQueue` is always `0` here — uploads are handled synchronously per-request, there's no server-side backlog to report. |

### Errors

All errors are JSON: `{ "error": "<Type>", "message": "<human-readable>" }`.
Validation errors additionally include a `fields` array.

| Status | Meaning |
|---|---|
| 400 | Validation error (bad/missing fields) |
| 401 | Missing/invalid/expired token, or bad credentials |
| 404 | Not found (or not yours) |
| 409 | Email already registered |
| 413 | Upload exceeds `MAX_UPLOAD_MB` |
| 415 | Unsupported audio file type |
| 429 | Rate limit exceeded |
| 500 | Unhandled server error |

---

## 5. Real-time updates (Socket.IO)

Connect with a JWT to join your personal room and receive live events:

```js
const socket = io("http://<your-computer-ip>:3000", { auth: { token: myJwt } });
socket.on("recording:synced", (data) => {
  // { id, localId, title } — fired right after a successful upload
});
```

Anonymous connections are also accepted (they just won't receive
per-user events) — useful for a general connection-health indicator.

---

## 6. Security

- **Passwords:** hashed with bcrypt (cost factor 10), never stored or logged in plaintext.
- **JWT:** signed with your `JWT_SECRET`, default 30-day expiry (`JWT_EXPIRY` in `.env`).
- **Helmet:** standard secure headers on every response.
- **Rate limiting:** general API (300 req/15min), stricter on auth (20/15min) and uploads (60/15min) — all per IP.
- **File validation:** MIME-type allow-list + server-generated filenames (the client's original filename is never trusted or written to disk) + hard size cap.
- **Input validation:** `express-validator` on register/login/profile; manual length-capping on all recording/log fields to prevent oversized payloads from bloating the DB.
- **CORS:** open (`origin: reflect any`) by default because this is built for LAN/file:// testing where the `Origin` header is unpredictable or `null`. **Lock this down before any public deployment** — see below.

### Known simplifications (by design, for a local-testing backend)

- No JWT blacklist — a stolen token remains valid until it expires. Fine for local dev; add Redis-backed blacklisting or short-lived tokens + refresh tokens before shipping this publicly.
- No email verification or password reset flow (the frontend's "forgot password" UI still runs its old local-only demo simulation — it isn't wired to this backend, since no such endpoint was in scope here).
- No account lockout after repeated failed logins beyond the general rate limiter.
- Social login (Google/Apple) and OTP/biometric login in the frontend remain simulated demos — this backend only implements email/password auth, matching the spec provided.

---

## 7. Production Deployment

This backend was built and tested for **local network testing**, not public
internet exposure. Before deploying it publicly:

1. **Lock down CORS** in `server.js` — replace the reflect-any-origin config
   with an explicit allow-list of your real frontend domain(s).
2. **Put it behind HTTPS.** Use a reverse proxy (nginx, Caddy) or a platform
   that terminates TLS for you (Render, Railway, Fly.io, a VPS + Caddy).
   Never run this raw on the public internet over plain HTTP.
3. **Move off SQLite for multi-instance deployments.** SQLite is great for a
   single-server local/dev setup; for real production scale or multiple app
   instances, swap `database/db.js` for Postgres/MySQL — the rest of the app
   only calls a small set of functions from that one file, so the blast
   radius of that change is contained.
4. **Move uploaded files to object storage** (S3-compatible) instead of local
   disk if you deploy on ephemeral/container infrastructure — local disk
   won't survive a redeploy on most PaaS platforms.
5. **Add a JWT blacklist/refresh-token flow** if you need real logout and
   shorter-lived tokens.
6. **Set `NODE_ENV=production`** in `.env` (tightens Morgan logging format).
7. **Review rate limits** for your expected real traffic — the defaults here
   are tuned for a handful of local testers, not public load.
8. **Back up `database/faithnotes.sqlite` and `uploads/`** regularly if you
   do keep SQLite + local disk for a small deployment.

---

## 8. What's been tested

Every endpoint below was exercised end-to-end against a running instance of
this exact code before delivery (register → login → profile → upload →
list → get → delete → sync → logs), including negative cases:

- ✅ Register, duplicate-email rejection (409), weak-password rejection (400)
- ✅ Login success and wrong-password rejection (401)
- ✅ Profile get/update with a valid token; profile access rejected with no token (401)
- ✅ Recording upload with full metadata; file byte-for-byte verified after round-trip through disk storage and static serving
- ✅ Unsupported file type rejected (415)
- ✅ List/get/delete recordings, including disk file cleanup on delete
- ✅ Sync status and sync acknowledge endpoints
- ✅ Batch log ingestion and filtered log retrieval
- ✅ Security headers present (Helmet), 404 handler, general error shape

What was **not** tested here (can't be, from this environment): actual
Android Chrome behavior, real Wi-Fi LAN connectivity between two physical
devices, and Socket.IO push over a real network — those require your actual
phone and computer, per the Android testing steps above.

---

## 9. Automated tests

```bash
cd backend
npm test
```

Runs `backend/test/api.test.js` using Node's built-in test runner (`node
--test`) — no test framework was added as a dependency, matching the rest of
this project's "no framework migrations" approach. Tests start a real
instance of the server against a throwaway SQLite database
(`test/test.sqlite`, deleted automatically when the run finishes) and make
real HTTP requests against it.

Current coverage: server health, registration (including duplicate-email
and weak-password rejection), login (including wrong-password rejection),
profile auth enforcement, recording upload/list/delete, rejection of
non-audio uploads, malformed-JSON error handling, and — the one worth
calling out specifically — that **one user cannot read, or delete, another
user's recording by guessing its ID** (a real IDOR/ownership check, not just
a happy-path test).

Not yet covered: sync endpoints, log ingestion, Socket.IO events, and the
frontend (which has no automated tests at all — see `SECURITY.md` and
`CHANGELOG.md` for the current state).
