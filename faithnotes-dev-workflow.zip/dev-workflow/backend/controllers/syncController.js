// controllers/syncController.js
// Design note: JSON can't efficiently carry binary audio, so actual file bytes
// always go through POST /api/recordings/upload (multipart). This /api/sync
// endpoint is what the frontend's queue processor calls once per queued item
// to hand off metadata + trigger the same upload path, and to report back a
// per-item result so the client can mark that item Synced/Failed/Retrying in
// its local IndexedDB queue. GET /api/sync/status reports server-side sync
// health; the client combines it with its own local queue length for the
// full picture, since the server has no visibility into what's still sitting
// in the browser's IndexedDB.

const db = require('../database/db');

function syncStatus(req, res) {
  const total = db.prepare('SELECT COUNT(*) AS c FROM recordings WHERE user_id = ?').get(req.user.id).c;
  const lastSync = db.prepare('SELECT synced_at FROM recordings WHERE user_id = ? ORDER BY synced_at DESC LIMIT 1').get(req.user.id);
  const recentEvents = db.prepare('SELECT * FROM sync_events WHERE user_id = ? ORDER BY created_at DESC LIMIT 20').all(req.user.id);
  res.json({
    serverTime: new Date().toISOString(),
    totalRecordingsOnServer: total,
    lastSyncedAt: lastSync ? lastSync.synced_at : null,
    recentSyncEvents: recentEvents.map(e => ({ localId: e.local_id, status: e.status, at: e.created_at })),
    note: 'This reflects server-side state only. The count of items still queued for upload lives in the browser\'s IndexedDB — this backend has no visibility into a device it hasn\'t heard from yet.'
  });
}

// A lightweight endpoint the client can call for items that only need a
// metadata acknowledgement (e.g. re-announcing a sync attempt without
// re-uploading a file that already made it to the server on a prior try).
function syncAcknowledge(req, res) {
  const { localId, status } = req.body || {};
  if (!localId) return res.status(400).json({ error: 'ValidationError', message: 'localId is required.' });
  const { v4: uuidv4 } = require('uuid');
  db.prepare('INSERT INTO sync_events (id, user_id, local_id, status) VALUES (?,?,?,?)')
    .run(uuidv4(), req.user.id, localId, status || 'synced');
  res.json({ message: 'Sync event recorded.', localId, status: status || 'synced' });
}

module.exports = { syncStatus, syncAcknowledge };
