// controllers/authController.js
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');
const db = require('../database/db');

const TOKEN_EXPIRY = process.env.JWT_EXPIRY || '30d';

function signToken(user) {
  return jwt.sign({ sub: user.id, email: user.email }, process.env.JWT_SECRET, { expiresIn: TOKEN_EXPIRY });
}
function publicUser(row) {
  if (!row) return null;
  return {
    id: row.id, name: row.name, email: row.email, church: row.church,
    location: row.location, phone: row.phone, plan: row.plan, createdAt: row.created_at
  };
}

async function register(req, res) {
  const { name, email, password, church, location, phone } = req.body;
  if (!name || !email || !password) {
    return res.status(400).json({ error: 'ValidationError', message: 'name, email, and password are required.' });
  }
  if (password.length < 8) {
    return res.status(400).json({ error: 'ValidationError', message: 'Password must be at least 8 characters.' });
  }
  const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(email.toLowerCase().trim());
  if (existing) {
    return res.status(409).json({ error: 'Conflict', message: 'An account with this email already exists.' });
  }
  const id = uuidv4();
  const passwordHash = await bcrypt.hash(password, 10);
  db.prepare(`INSERT INTO users (id, name, email, password_hash, church, location, phone) VALUES (?,?,?,?,?,?,?)`)
    .run(id, name.trim(), email.toLowerCase().trim(), passwordHash, church || '', location || '', phone || '');
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(id);
  const token = signToken(user);
  console.log(`[FaithNotes:Backend] New user registered: ${user.email}`);
  res.status(201).json({ token, user: publicUser(user) });
}

async function login(req, res) {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json({ error: 'ValidationError', message: 'email and password are required.' });
  }
  const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email.toLowerCase().trim());
  if (!user) {
    return res.status(401).json({ error: 'Unauthorized', message: 'Invalid email or password.' });
  }
  const ok = await bcrypt.compare(password, user.password_hash);
  if (!ok) {
    return res.status(401).json({ error: 'Unauthorized', message: 'Invalid email or password.' });
  }
  const token = signToken(user);
  console.log(`[FaithNotes:Backend] Login: ${user.email}`);
  res.json({ token, user: publicUser(user) });
}

function logout(req, res) {
  // JWTs are stateless — there's nothing to invalidate server-side without a
  // token blacklist/store, which this local-testing backend doesn't add.
  // The client is responsible for discarding the token. This endpoint exists
  // so the frontend has a clean, explicit call to make on sign-out.
  res.json({ message: 'Logged out. Discard the token on the client.' });
}

function getProfile(req, res) {
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id);
  if (!user) return res.status(404).json({ error: 'NotFound', message: 'User not found.' });
  res.json({ user: publicUser(user) });
}

function updateProfile(req, res) {
  const { name, church, location, phone } = req.body;
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id);
  if (!user) return res.status(404).json({ error: 'NotFound', message: 'User not found.' });
  db.prepare(`UPDATE users SET name=?, church=?, location=?, phone=?, updated_at=datetime('now') WHERE id=?`)
    .run(name ?? user.name, church ?? user.church, location ?? user.location, phone ?? user.phone, user.id);
  const updated = db.prepare('SELECT * FROM users WHERE id = ?').get(user.id);
  res.json({ user: publicUser(updated) });
}

module.exports = { register, login, logout, getProfile, updateProfile };
