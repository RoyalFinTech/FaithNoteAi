// controllers/recordingsController.js
const fs = require('fs');
const path = require('path');
const { v4: uuidv4 } = require('uuid');
const db = require('../database/db');

function toPublicRecording(row, req) {
  return {
    id: row.id,
    localId: row.local_id,
    title: row.title,
    preacher: row.preacher,
    church: row.church,
    location: row.location,
    date: row.sermon_date,
    category: row.category,
    fileSize: row.file_size,
    mimeType: row.mime_type,
    durationSec: row.duration_sec,
    codec: row.codec,
    sampleRate: row.sample_rate,
    channels: row.channels,
    bitrate: row.bitrate,
    device: row.device,
    browser: row.browser,
    avgInputLevel: row.avg_input_level,
    peakInputLevel: row.peak_input_level,
    noiseLabel: row.noise_label,
    sessionId: row.session_id,
    waveformMetadata: safeParse(row.waveform_metadata),
    transcript: row.transcript,
    createdAt: row.created_at,
    syncedAt: row.synced_at,
    audioUrl: `${req.protocol}://${req.get('host')}/uploads/${path.basename(row.filepath)}`
  };
}
function safeParse(str) { try { return str ? JSON.parse(str) : null; } catch (e) { return null; } }

function uploadRecording(req, res) {
  if (!req.file) {
    return res.status(400).json({ error: 'ValidationError', message: 'No audio file was included in the upload (field name must be "audio").' });
  }
  const b = req.body || {};
  const id = uuidv4();
  const row = {
    id,
    user_id: req.user.id,
    local_id: b.localId || '',
    title: (b.title || 'Untitled Sermon').slice(0, 200),
    preacher: (b.preacher || '').slice(0, 200),
    church: (b.church || '').slice(0, 200),
    location: (b.location || '').slice(0, 200),
    sermon_date: (b.date || '').slice(0, 40),
    category: (b.category || '').slice(0, 60),
    filename: req.file.filename,
    filepath: req.file.path,
    mime_type: req.file.mimetype,
    file_size: req.file.size,
    duration_sec: parseInt(b.durationSec, 10) || 0,
    codec: (b.codec || '').slice(0, 100),
    sample_rate: parseInt(b.sampleRate, 10) || 0,
    channels: parseInt(b.channels, 10) || 0,
    bitrate: parseInt(b.bitrate, 10) || 0,
    device: (b.device || '').slice(0, 200),
    browser: (b.browser || '').slice(0, 200),
    avg_input_level: parseFloat(b.avgInputLevel) || 0,
    peak_input_level: parseFloat(b.peakInputLevel) || 0,
    noise_label: (b.noiseLabel || '').slice(0, 40),
    session_id: (b.sessionId || '').slice(0, 80),
    waveform_metadata: typeof b.waveformMetadata === 'string' ? b.waveformMetadata.slice(0, 20000) : '',
    transcript: (b.transcript || '').slice(0, 200000)
  };
  db.prepare(`INSERT INTO recordings (
      id, user_id, local_id, title, preacher, church, location, sermon_date, category,
      filename, filepath, mime_type, file_size, duration_sec, codec, sample_rate, channels,
      bitrate, device, browser, avg_input_level, peak_input_level, noise_label, session_id,
      waveform_metadata, transcript
    ) VALUES (@id,@user_id,@local_id,@title,@preacher,@church,@location,@sermon_date,@category,
      @filename,@filepath,@mime_type,@file_size,@duration_sec,@codec,@sample_rate,@channels,
      @bitrate,@device,@browser,@avg_input_level,@peak_input_level,@noise_label,@session_id,
      @waveform_metadata,@transcript)`).run(row);

  if (row.local_id) {
    db.prepare('INSERT INTO sync_events (id, user_id, local_id, status) VALUES (?,?,?,?)')
      .run(uuidv4(), req.user.id, row.local_id, 'synced');
  }

  const saved = db.prepare('SELECT * FROM recordings WHERE id = ?').get(id);
  console.log(`[FaithNotes:Backend] Recording uploaded: ${saved.title} (${saved.file_size} bytes) by user ${req.user.id}`);

  const io = req.app.get('io');
  if (io) io.to(`user:${req.user.id}`).emit('recording:synced', { id: saved.id, localId: saved.local_id, title: saved.title });

  res.status(201).json({ recording: toPublicRecording(saved, req) });
}

function listRecordings(req, res) {
  const rows = db.prepare('SELECT * FROM recordings WHERE user_id = ? ORDER BY created_at DESC').all(req.user.id);
  res.json({ recordings: rows.map(r => toPublicRecording(r, req)), count: rows.length });
}

function getRecording(req, res) {
  const row = db.prepare('SELECT * FROM recordings WHERE id = ? AND user_id = ?').get(req.params.id, req.user.id);
  if (!row) return res.status(404).json({ error: 'NotFound', message: 'Recording not found.' });
  res.json({ recording: toPublicRecording(row, req) });
}

function deleteRecording(req, res) {
  const row = db.prepare('SELECT * FROM recordings WHERE id = ? AND user_id = ?').get(req.params.id, req.user.id);
  if (!row) return res.status(404).json({ error: 'NotFound', message: 'Recording not found.' });
  db.prepare('DELETE FROM recordings WHERE id = ?').run(row.id);
  fs.unlink(row.filepath, (err) => {
    if (err) console.warn('[FaithNotes:Backend] Could not remove audio file from disk:', err.message);
  });
  console.log(`[FaithNotes:Backend] Recording deleted: ${row.title} (${row.id})`);
  res.json({ message: 'Recording deleted.', id: row.id });
}

module.exports = { uploadRecording, listRecordings, getRecording, deleteRecording };
