// controllers/statusController.js
const fs = require('fs');
const path = require('path');
const db = require('../database/db');
const { UPLOAD_DIR } = require('../middleware/upload');

const API_VERSION = '1.0.0';
const startedAt = Date.now();

function getStorageUsedBytes() {
  try {
    const files = fs.readdirSync(UPLOAD_DIR);
    let total = 0;
    for (const f of files) {
      const stat = fs.statSync(path.join(UPLOAD_DIR, f));
      if (stat.isFile()) total += stat.size;
    }
    return total;
  } catch (e) { return 0; }
}

function status(req, res) {
  let dbConnected = true;
  let recordingCount = 0;
  try {
    recordingCount = db.prepare('SELECT COUNT(*) AS c FROM recordings').get().c;
  } catch (e) { dbConnected = false; }

  const storageBytes = getStorageUsedBytes();

  res.json({
    serverOnline: true,
    databaseConnected: dbConnected,
    uploadQueue: 0, // this server processes uploads synchronously (no server-side queue/backlog)
    currentTime: new Date().toISOString(),
    uptimeSec: Math.round((Date.now() - startedAt) / 1000),
    storageUsedBytes: storageBytes,
    storageUsedMB: Math.round((storageBytes / (1024 * 1024)) * 100) / 100,
    totalRecordings: recordingCount,
    apiVersion: API_VERSION
  });
}

module.exports = { status };
