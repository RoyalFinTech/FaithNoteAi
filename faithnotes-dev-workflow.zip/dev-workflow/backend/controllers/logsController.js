// controllers/logsController.js
const { v4: uuidv4 } = require('uuid');
const db = require('../database/db');

const VALID_TYPES = new Set(['warning', 'clipping', 'silence', 'mic_change', 'recovery', 'error', 'session', 'info']);

function createLog(req, res) {
  const entries = Array.isArray(req.body) ? req.body : [req.body];
  const insert = db.prepare(`INSERT INTO logs (id, user_id, session_id, type, message, browser, meta) VALUES (?,?,?,?,?,?,?)`);
  const insertMany = db.transaction((items) => {
    let count = 0;
    for (const entry of items) {
      if (!entry || !entry.message) continue;
      const type = VALID_TYPES.has(entry.type) ? entry.type : 'info';
      insert.run(
        uuidv4(),
        req.user ? req.user.id : null,
        (entry.sessionId || '').slice(0, 80),
        type,
        String(entry.message).slice(0, 2000),
        (entry.browser || '').slice(0, 200),
        entry.meta ? JSON.stringify(entry.meta).slice(0, 5000) : ''
      );
      count++;
    }
    return count;
  });
  const count = insertMany(entries);
  res.status(201).json({ message: `${count} log entr${count === 1 ? 'y' : 'ies'} recorded.`, count });
}

function listLogs(req, res) {
  if (!req.user) return res.status(401).json({ error: 'Unauthorized', message: 'Log in to view stored logs.' });
  const { type, sessionId, limit } = req.query;
  let sql = 'SELECT * FROM logs WHERE user_id = ?';
  const params = [req.user.id];
  if (type) { sql += ' AND type = ?'; params.push(type); }
  if (sessionId) { sql += ' AND session_id = ?'; params.push(sessionId); }
  sql += ' ORDER BY created_at DESC LIMIT ?';
  params.push(Math.min(parseInt(limit, 10) || 100, 500));
  const rows = db.prepare(sql).all(...params);
  res.json({
    logs: rows.map(r => ({
      id: r.id, sessionId: r.session_id, type: r.type, message: r.message,
      browser: r.browser, meta: safeParse(r.meta), createdAt: r.created_at
    })),
    count: rows.length
  });
}
function safeParse(str) { try { return str ? JSON.parse(str) : null; } catch (e) { return null; } }

module.exports = { createLog, listLogs };
