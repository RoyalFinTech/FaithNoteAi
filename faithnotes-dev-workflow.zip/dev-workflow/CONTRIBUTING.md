# Contributing to FaithNotes AI

Thanks for your interest in contributing. This document covers how the
project is structured, how to get it running locally, and what's expected
before submitting a change.

## Project structure

```
dev-workflow/
├── backend/          Node/Express/SQLite API (auth, recordings, sync, logs)
├── dev-server/        Zero-dependency static server for the frontend
├── public/            The frontend itself (single self-contained HTML file)
├── start-all.js        Runs backend + dev-server together
└── README.md           Full local network / Android testing walkthrough
```

The frontend (`public/faithnotes-ai.html`) is intentionally a single
self-contained file — no build step, no bundler, no framework. All of its
CSS and JavaScript live inline in that one file. This is a deliberate
choice (see the README for why); changes to the frontend mean editing that
file directly.

## Getting set up

```bash
git clone <this repo>
cd dev-workflow
npm run setup          # installs backend dependencies
cp backend/.env.example backend/.env
```

Open `backend/.env` and set a real `JWT_SECRET`:

```bash
node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"
```

Then start everything:

```bash
npm start
```

See the root `README.md` for the full walkthrough, including testing on an
actual Android phone over your local network.

## Before submitting a change

1. **Run the linter** and make sure it passes cleanly:
   ```bash
   npm run lint:all
   ```
   This covers the backend, the dev server, and the frontend's embedded
   script (via `eslint-plugin-html`).

2. **Manually verify your change actually works.** There is currently no
   automated test suite (`npm test` says so honestly rather than
   pretending — see `SECURITY.md` and the README for the current state of
   testing). Until one exists, describe what you tested and how in your
   pull request description: which endpoints you hit, what you saw in the
   browser, what device/browser you tested on if it's frontend-related.

3. **Keep the frontend framework-free.** Don't introduce a bundler,
   TypeScript, or a UI framework into `public/faithnotes-ai.html` without
   discussing it first — the single-file, zero-build-step design is
   intentional (it's what makes the "open this file on your phone" testing
   workflow possible at all).

4. **Don't commit secrets.** Check `.env.example` stays in sync if you add
   a new environment variable, and make sure your actual `.env` is never
   staged (it's gitignored, but double-check).

5. **Update the README** if you change setup steps, add an endpoint, or
   change how something is configured. Stale setup docs are worse than no
   docs.

## Reporting bugs

Open an issue with:
- What you expected to happen
- What actually happened
- Steps to reproduce
- Your environment (OS, Node version, browser + version if frontend-related)

## Security issues

Please see `SECURITY.md` — don't open a public issue for a security
vulnerability.

## Code style

- Plain JavaScript (CommonJS) throughout — no TypeScript, no transpilation.
- The backend follows a conventional Express layout: `routes/` →
  `controllers/` → `database/`, with cross-cutting concerns in
  `middleware/`.
- The frontend uses `onclick="..."` attribute handlers and `data-*`
  attributes rather than addEventListener-heavy DOM wiring — this is a
  consistent, intentional pattern throughout the file, not an oversight.
- Prefer editing/extending existing patterns over introducing new ones,
  especially in the frontend where consistency matters more than any one
  file's local elegance.
