# Security Policy

## Reporting a Vulnerability

If you discover a security vulnerability in FaithNotes AI, please report it
privately rather than opening a public GitHub issue. Open an issue only
after you've had a chance to report it privately and it's been addressed,
or if you believe public disclosure is otherwise appropriate.

There is currently no dedicated security contact address or bug bounty
program for this project — if you're deploying this yourself, replace this
section with your own team's real contact process before publishing.

Please include:
- A description of the vulnerability and its potential impact
- Steps to reproduce it
- Any relevant logs, requests, or code paths

## Supported Versions

This project does not yet have a formal versioned release/support policy.
Security fixes are applied to the current `main` branch.

## Security Measures Already in Place

This reflects what's actually implemented in the codebase today, not
aspirational goals:

- **Password storage:** bcrypt hashing (cost factor 10) — passwords are
  never stored or logged in plaintext.
- **Authentication:** JSON Web Tokens (JWT), signed with a secret you
  provide via `.env` (`JWT_SECRET`). The server refuses to start with an
  unset or placeholder secret.
- **Transport/headers:** [Helmet](https://helmetjs.github.io/) sets standard
  secure HTTP headers on every response.
- **Rate limiting:** general API (300 req/15min per IP), stricter limits on
  authentication (20/15min) and uploads (60/15min), via
  `express-rate-limit`.
- **Input validation:** `express-validator` on registration/login/profile
  endpoints; manual length-capping on recording and log fields to prevent
  oversized payloads.
- **File upload safety:** MIME-type allow-list, server-generated filenames
  (the client's original filename is never trusted or written to disk),
  and a hard upload size cap (`MAX_UPLOAD_MB` in `.env`).
- **CORS:** currently configured to reflect any origin, because this
  backend is built for local network / `file://` testing where the
  `Origin` header is unpredictable or `null`. **This must be locked down to
  an explicit allow-list before any public deployment** — see
  `backend/README.md`, section 7 ("Production Deployment").

## Known Limitations (Not Yet Addressed)

Documented honestly rather than left implicit:

- **No JWT revocation/blacklist.** A stolen token remains valid until it
  expires (`JWT_EXPIRY`, default 30 days). There is no server-side session
  store to invalidate a token early. Consider short-lived access tokens +
  refresh tokens, or a Redis-backed blacklist, before any production use
  involving sensitive data.
- **No email verification or password reset flow** on the backend. (The
  frontend's "forgot password" screen still runs an old local-only demo
  simulation — it is not connected to this backend, since no such endpoint
  exists.)
- **No account lockout** after repeated failed login attempts beyond the
  general rate limiter.
- **SQLite, single file, no encryption at rest.** Fine for local
  development; consider your own encryption/backup strategy if you deploy
  this with real user data.
- **Automated test coverage is partial.** `backend/test/` has real integration
  tests (auth, registration validation, and ownership/IDOR checks on
  recordings — run via `npm test` inside `backend/`, using Node's built-in
  test runner, no added dependencies) covering the security-relevant checks
  called out above. Everything else in this document has been manually
  verified (see `backend/README.md` section 8, "What's been tested") but
  isn't yet covered by an automated test. The frontend and dev-server have
  no automated tests at all. See `CHANGELOG.md` for the current state.

If you build on top of this project for a real deployment, treat the items
in this section as a starting checklist, not a complete one.
