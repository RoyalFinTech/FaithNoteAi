# Changelog

All notable changes to this project are documented here. Format loosely
follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/).

This project has not yet had a tagged release — everything below is
grouped under **[Unreleased]** since it reflects the full development
history to date, not a series of dated releases.

## [Unreleased]

### Added
- Complete FaithNotes AI frontend: onboarding, authentication screens,
  dashboard, sermon recording studio, sermon detail view with 9 AI analysis
  types (summary, theme, key points, prayer points, reflection questions,
  action steps, Bible study guide, youth guide, small-group questions), AI
  chat assistant, sermon library with search/filters, Bible verse
  collection, prayer journal, favorites, settings, admin panel,
  subscription plan UI, and TXT/PDF/DOCX export — delivered as a single
  self-contained HTML file with no build step.
- Backend API (Node/Express/SQLite): JWT-based registration and login,
  profile management, recording upload/list/get/delete, offline sync
  status/acknowledge endpoints, structured event logging, and a server
  status endpoint. Secured with Helmet, rate limiting, input validation,
  bcrypt password hashing, and MIME-type/size-limited file uploads.
- Real-time updates via Socket.IO (per-user rooms, recording-synced events).
- Frontend wired to the backend: configurable backend URL, real
  register/login with automatic fallback to local-only mode if no backend
  is configured or reachable, per-recording sync status badges
  (queued/uploading/synced/failed/local-only), a live connection indicator,
  and background retry on reconnect.
- Microphone diagnostics engine: exact `getUserMedia()` error detection
  (NotAllowedError, NotFoundError, NotReadableError, SecurityError,
  AbortError, OverconstrainedError, and more) with plain-language causes
  and per-browser fix instructions, a Permissions API pre-check, a
  dedicated Test Microphone diagnostics page, device enumeration and
  selection, and detection of restricted origins (`file://`, `content://`)
  where the browser never issues a permission prompt at all — shown as a
  distinct, non-blaming message rather than a generic "permission denied."
- Recording engine: pause/resume/stop, live waveform (canvas + frequency
  bars), color-coded input level meter with peak hold, silence detection,
  clipping detection, background noise estimate, a live recording-quality
  panel (codec, sample rate, channels, bitrate, mic, permission state,
  browser, secure-context status), automatic device-change handling with
  fallback to the system default microphone, one-shot automatic recovery
  if a recording is interrupted, and structured per-session logs.
- Native `<audio controls>` playback for recorded sermons, backed by an
  IndexedDB persistence layer so recordings survive a page reload (a dead
  in-memory `blob:` URL is transparently rehydrated from IndexedDB).
- Accessibility pass: ARIA labels and roles, keyboard navigation, visible
  focus states, `prefers-reduced-motion` and `prefers-contrast` support.
- Local network development workflow: a zero-dependency static file server
  (binds to `0.0.0.0`, prints LAN URLs, supports HTTPS via mkcert-style
  certs auto-detected in `certs/`), a combined launcher (`start-all.js`)
  that runs the backend and dev server together, and full documentation
  for testing on Android Chrome over Wi-Fi — including both supported
  paths to satisfy the browser's secure-context requirement for
  microphone access during local testing (a Chrome dev flag, or local
  HTTPS via mkcert).
- `.gitignore`, `.env.example` (kept in sync with every environment
  variable actually read by the backend), `SECURITY.md`, `CONTRIBUTING.md`,
  `LICENSE` (MIT — confirm this matches your intended license before
  publishing), and this changelog.
- ESLint configuration and `npm run lint` / `lint:frontend` / `lint:backend`
  / `lint:all` scripts, covering the backend, the dev server, and the
  frontend's embedded script (via `eslint-plugin-html`).
- `CODE_OF_CONDUCT.md`, GitHub issue templates (bug report, feature
  request), a pull request template, `.github/dependabot.yml`, and a
  `release.yml` workflow that creates a GitHub Release on a version tag
  (there's no build artifact to publish, so that's all it does).
- A backend `Dockerfile` and root `docker-compose.yml` — written but **not
  build-tested** (Docker wasn't available in the environment that produced
  them); verify with `docker compose up --build` before relying on them.
- A real backend integration test suite (`backend/test/api.test.js`, using
  Node's built-in test runner — no framework added), covering
  registration/login validation and, notably, an ownership/IDOR check
  confirming one user cannot read or delete another user's recording by
  guessing its ID. `npm test` inside `backend/` now runs these for real.
- Prayer Journal: categories (Thanksgiving, Worship, Confession,
  Intercession, Personal Needs, Family, Church), free-text tags, search,
  an edit flow (previously add-only), and a plain-text export of the whole
  journal.
- Bible Verse Library: personal notes and categories per verse (stored
  independently of favorites, so any verse can have a note — not just
  favorited ones), copy-to-clipboard, native share (Web Share API with a
  clipboard fallback), category filter chips, and clearer linking back to
  the sermon a verse came from.
- Sermon transcript: manual editing with autosave, a capped version
  history (last 10 versions, including the version just before a Whisper
  re-transcription overwrites it — so a manual edit is never silently lost
  with no way back), and clickable highlighting of detected Bible verse
  mentions directly in the transcript text, jumping to the Bible Verses tab.
- An explicit "AI-generated interpretation, not part of the original
  sermon or Scripture" disclaimer at the top of the AI Analysis tab.

### Fixed
- A recording-start race condition: rapidly tapping the record button
  before the microphone permission prompt resolved could start two
  concurrent recording sessions and leak the first audio stream. Fixed
  with an explicit re-entrancy guard.
- A related leak: if `getUserMedia()` succeeded but `MediaRecorder`
  construction failed afterward, the acquired microphone stream was never
  released. Now stopped explicitly on that failure path.
- Recording quality metadata (`sampleRate`) was always sent to the backend
  as `0` instead of the actual negotiated sample rate; now captured from
  the live audio track (with an AudioContext-based fallback) and verified
  to round-trip correctly.
- The IndexedDB audio-rehydration helper (`ensureSermonAudioURL`) existed
  but wasn't called anywhere, meaning Whisper re-transcription and backend
  upload could silently fail after a page reload (a dead `blob:` URL).
  Now wired into both paths.
- A missing database index on `sync_events.user_id`, despite that table
  always being queried by user — added and verified against the live
  schema.
- 12 real ESLint findings in the frontend (8 empty `catch` blocks without
  an explanatory comment, 4 function declarations nested inside blocks
  with browser-inconsistent hoisting behavior) — fixed with documented
  intentional-ignore comments and conversion to `const` arrow function
  expressions respectively.
- A malformed JSON request body previously returned a generic 500-style
  "something went wrong" error; now returns a clear 400 with a specific
  message.
- An ESLint config cascading bug (introduced during this same cleanup)
  where the root config's settings unintentionally suppressed lint
  coverage of the entire backend when run from within `backend/`; fixed
  with `root: true` isolation.
- Removed a leftover `eslint` devDependency and duplicate `lint` script
  from `dev-server/package.json` that contradicted its own "zero
  dependency" description.
- 30 form fields had visible label text with no programmatic association
  to their input (screen readers heard blank fields) — fixed via `for=`/
  `id` pairing or `aria-label` on every field, verified none remain.
- No skip link existed; added one, targeting a stable anchor present
  regardless of which app view is active.
- The global toast notification system had no `aria-live` region, so
  every success/error message app-wide was silent to screen readers.
- 5 real WCAG AA color-contrast failures, found by computing actual
  contrast ratios from the app's hex values rather than eyeballing them
  (`--blue` on light backgrounds ranged 3.70–4.20:1 depending on context;
  AA requires 4.5:1 for text that size). Added `--blue-text`/
  `--success-text` variants and applied them only at real text-usage
  sites, leaving the base colors untouched where they're used as borders
  or decorative accents (which have a looser 3:1 threshold and already
  passed).
- The backend's CORS config set `credentials: true`, which was inert —
  confirmed the frontend never sends `credentials:'include'` and the
  backend has no cookie-based auth anywhere (Bearer tokens only). Removed,
  narrowing the CORS surface with zero functional change.
- Two missing security headers: `Permissions-Policy` (Helmet doesn't set
  this by default) and `Cache-Control: no-store` on every
  sensitive/authenticated endpoint (profile, recordings, sync, logs) — the
  public status endpoint deliberately stays cacheable.
- No graceful shutdown existed — SIGTERM/SIGINT killed the process
  immediately, cutting off in-flight requests. Added a handler that stops
  accepting new connections and closes Socket.IO and the database first.
  A bug in that same fix (`process.exit()` racing ahead of an async
  callback, silently skipping the Socket.IO close log) was found and
  corrected in the same pass.

### Known limitations (see `SECURITY.md` for the full list)
- Automated test coverage is partial: `backend/test/` has real integration
  tests (auth, validation, and an IDOR/ownership check), but sync/logs
  endpoints, Socket.IO, the frontend, and the dev server have none yet.
- No JWT revocation/blacklist, no email verification or password reset on
  the backend, no account lockout beyond general rate limiting.
- OTP verification, social login (Google/Apple), and biometric login in
  the frontend remain simulated/demo flows — not connected to any real
  provider or the backend, since none was in scope.
- CORS currently reflects any origin, appropriate for local network
  testing only — must be locked down before any public deployment.
- The `Dockerfile`/`docker-compose.yml` were authored but not
  build-tested (Docker wasn't available when they were written) — run
  `docker compose up --build` yourself before relying on them.
