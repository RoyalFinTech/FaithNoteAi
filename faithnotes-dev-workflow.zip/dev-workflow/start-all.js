// start-all.js
// Convenience launcher: starts the FaithNotes backend API server and the
// frontend dev server together with one command, so you don't need two
// terminal windows for local network testing.
//
// Run with: node start-all.js
// Stop with: Ctrl+C (both child processes are shut down cleanly)
//
// This is optional — you can always run `node backend/server.js` and
// `node dev-server/server.js` separately in two terminals instead, which
// can make it easier to read each one's logs. See the README.

const { spawn } = require('child_process');
const path = require('path');
const fs = require('fs');

const BACKEND_DIR = path.join(__dirname, 'backend');
const DEVSERVER_DIR = path.join(__dirname, 'dev-server');

function checkPrereqs() {
  const problems = [];
  if (!fs.existsSync(path.join(BACKEND_DIR, 'node_modules'))) {
    problems.push('backend/node_modules is missing — run "npm install" inside backend/ first.');
  }
  if (!fs.existsSync(path.join(BACKEND_DIR, '.env'))) {
    problems.push('backend/.env is missing — copy backend/.env.example to backend/.env and set a real JWT_SECRET first.');
  }
  if (!fs.existsSync(path.join(__dirname, 'public', 'faithnotes-ai.html'))) {
    problems.push('public/faithnotes-ai.html is missing — the dev server has nothing to serve.');
  }
  return problems;
}

function prefixedPipe(child, label, color) {
  const reset = '\x1b[0m';
  const prefix = color + '[' + label + ']' + reset + ' ';
  const pipe = (stream) => {
    stream.on('data', (data) => {
      data.toString().split('\n').filter(Boolean).forEach(line => {
        process.stdout.write(prefix + line + '\n');
      });
    });
  };
  pipe(child.stdout);
  pipe(child.stderr);
}

function main() {
  const problems = checkPrereqs();
  if (problems.length) {
    console.error('Cannot start — please fix the following first:\n');
    problems.forEach(p => console.error('  ✗ ' + p));
    console.error('\nSee README.md for full setup steps.');
    process.exit(1);
  }

  console.log('Starting FaithNotes backend + dev server together. Press Ctrl+C to stop both.\n');

  const backend = spawn('node', ['server.js'], { cwd: BACKEND_DIR });
  const devserver = spawn('node', ['server.js'], { cwd: DEVSERVER_DIR });

  prefixedPipe(backend, 'backend', '\x1b[36m');   // cyan
  prefixedPipe(devserver, 'frontend', '\x1b[33m'); // yellow

  let shuttingDown = false;
  function shutdown() {
    if (shuttingDown) return;
    shuttingDown = true;
    console.log('\nShutting down…');
    backend.kill('SIGTERM');
    devserver.kill('SIGTERM');
    setTimeout(() => process.exit(0), 300);
  }
  process.on('SIGINT', shutdown);
  process.on('SIGTERM', shutdown);

  backend.on('exit', (code) => {
    if (!shuttingDown) {
      console.error('[backend] exited unexpectedly (code ' + code + ') — stopping dev server too.');
      shutdown();
    }
  });
  devserver.on('exit', (code) => {
    if (!shuttingDown) {
      console.error('[frontend] exited unexpectedly (code ' + code + ') — stopping backend too.');
      shutdown();
    }
  });
}

main();
