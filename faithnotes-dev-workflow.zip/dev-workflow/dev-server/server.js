// dev-server/server.js
// Lightweight static file server for the FaithNotes AI frontend — zero
// npm dependencies (uses only Node's built-in http/https/fs/os/path
// modules). Serves the /public folder, listens on 0.0.0.0 so devices on
// the same Wi-Fi (like your Android phone) can reach it, and prints every
// LAN URL it's reachable at.
//
// Run with: node server.js
// All configuration below is optional and has a sensible default — there is
// no .env file for this server (it has zero npm dependencies, including no
// dotenv). Set any of these inline instead, e.g.:
//   PORT=9000 node server.js
//   PORT        — port to listen on (default 8080)
//   HOST        — bind address (default 0.0.0.0)
//   PUBLIC_DIR  — folder to serve (default ../public relative to this file)
//   CERT_DIR    — folder to look for cert.pem/key.pem for HTTPS mode
//                 (default ../certs relative to this file)
//   DEFAULT_FILE — file served for "/" and as the fallback for unknown paths
//                  (default faithnotes-ai.html)
//
// HTTPS mode: if CERT_DIR contains both cert.pem and key.pem, this server
// automatically starts in HTTPS mode instead of HTTP. See the project
// README's "Local HTTPS with mkcert" section for how to generate those.

const http = require('http');
const https = require('https');
const fs = require('fs');
const os = require('os');
const path = require('path');

const PORT = parseInt(process.env.PORT, 10) || 8080;
const HOST = process.env.HOST || '0.0.0.0';
const PUBLIC_DIR = process.env.PUBLIC_DIR
  ? path.resolve(process.env.PUBLIC_DIR)
  : path.join(__dirname, '..', 'public');
const CERT_DIR = process.env.CERT_DIR
  ? path.resolve(process.env.CERT_DIR)
  : path.join(__dirname, '..', 'certs');
const DEFAULT_FILE = process.env.DEFAULT_FILE || 'faithnotes-ai.html';

const MIME_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.ico': 'image/x-icon',
  '.webmanifest': 'application/manifest+json',
  '.woff2': 'font/woff2',
  '.map': 'application/json; charset=utf-8'
};

function getLanAddresses() {
  const interfaces = os.networkInterfaces();
  const addresses = [];
  for (const name of Object.keys(interfaces)) {
    for (const iface of interfaces[name]) {
      // IPv4, not internal (skips 127.0.0.1), and not a virtual/docker-style adapter
      if (iface.family === 'IPv4' && !iface.internal) {
        addresses.push({ name, address: iface.address });
      }
    }
  }
  return addresses;
}

function safeJoin(base, requestPath) {
  // Prevent path traversal (../../etc/passwd style requests) by resolving
  // the final path and confirming it's still inside `base`.
  const decoded = decodeURIComponent(requestPath.split('?')[0]);
  const resolved = path.normalize(path.join(base, decoded));
  if (!resolved.startsWith(path.normalize(base))) return null;
  return resolved;
}

function requestHandler(req, res) {
  const urlPath = req.url === '/' ? '/' + DEFAULT_FILE : req.url;
  let filePath = safeJoin(PUBLIC_DIR, urlPath);

  if (!filePath) {
    res.writeHead(400, { 'Content-Type': 'text/plain' });
    res.end('Bad request.');
    return;
  }

  fs.stat(filePath, (err, stats) => {
    if (err || !stats.isFile()) {
      // Fall back to the default file for any unknown path — convenient for
      // single-page-app-style navigation, and means a typo'd path doesn't
      // dead-end with a bare 404 during dev testing.
      filePath = path.join(PUBLIC_DIR, DEFAULT_FILE);
      fs.stat(filePath, (err2, stats2) => {
        if (err2 || !stats2.isFile()) {
          res.writeHead(404, { 'Content-Type': 'text/plain' });
          res.end('Not found. Expected ' + DEFAULT_FILE + ' in ' + PUBLIC_DIR);
          return;
        }
        streamFile(filePath, res);
      });
      return;
    }
    streamFile(filePath, res);
  });
}

function streamFile(filePath, res) {
  const ext = path.extname(filePath).toLowerCase();
  const mime = MIME_TYPES[ext] || 'application/octet-stream';
  res.writeHead(200, {
    'Content-Type': mime,
    'Cache-Control': 'no-cache', // dev server — always serve the latest edit, never a stale cached copy
    'Access-Control-Allow-Origin': '*'
  });
  fs.createReadStream(filePath).pipe(res);
}

function hasHttpsCerts() {
  const certPath = path.join(CERT_DIR, 'cert.pem');
  const keyPath = path.join(CERT_DIR, 'key.pem');
  return fs.existsSync(certPath) && fs.existsSync(keyPath) ? { certPath, keyPath } : null;
}

function start() {
  if (!fs.existsSync(PUBLIC_DIR)) {
    console.error('[FaithNotes:DevServer] Public folder not found: ' + PUBLIC_DIR);
    console.error('[FaithNotes:DevServer] Create it, or set PUBLIC_DIR to point at your frontend files.');
    process.exit(1);
  }

  const certs = hasHttpsCerts();
  const scheme = certs ? 'https' : 'http';
  const server = certs
    ? https.createServer({ cert: fs.readFileSync(certs.certPath), key: fs.readFileSync(certs.keyPath) }, requestHandler)
    : http.createServer(requestHandler);

  server.listen(PORT, HOST, () => {
    const lanAddrs = getLanAddresses();
    console.log('==========================================================');
    console.log(' FaithNotes AI — Dev Server (' + scheme.toUpperCase() + ')');
    console.log('==========================================================');
    console.log(' Serving:  ' + PUBLIC_DIR);
    console.log(' Local:    ' + scheme + '://localhost:' + PORT);
    if (lanAddrs.length === 0) {
      console.log(' Network:  no LAN network interface detected — connect this');
      console.log('           machine to Wi-Fi/Ethernet to test from your phone.');
    } else {
      lanAddrs.forEach(a => {
        console.log(' Network:  ' + scheme + '://' + a.address + ':' + PORT + '   (' + a.name + ' — use this from your phone)');
      });
    }
    console.log('==========================================================');
    if (!certs) {
      console.log(' Running in HTTP mode. Plain HTTP to a LAN IP is NOT a');
      console.log(' secure context by default in Chrome, so getUserMedia()');
      console.log(' (microphone access) will be blocked on your phone unless');
      console.log(' you either:');
      console.log('   (a) use the chrome://flags dev workaround, or');
      console.log('   (b) generate local HTTPS certs (see README: "Local HTTPS with mkcert")');
      console.log(' Full step-by-step instructions are in the project README.');
      console.log('==========================================================');
    }
  });

  server.on('error', (err) => {
    if (err.code === 'EADDRINUSE') {
      console.error('[FaithNotes:DevServer] Port ' + PORT + ' is already in use. Set PORT to a different value and retry.');
    } else {
      console.error('[FaithNotes:DevServer] Server error:', err.message);
    }
    process.exit(1);
  });
}

start();
