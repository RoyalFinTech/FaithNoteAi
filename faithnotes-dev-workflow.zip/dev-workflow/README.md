# FaithNotes AI — Local Network Development Workflow

<!-- These badges point at a placeholder repo path. Replace
     YOUR-GITHUB-ORG/faithnotes-ai below with the real path once this is
     pushed to GitHub, or the badges will show as broken/unknown. -->
[![Lint](https://github.com/YOUR-GITHUB-ORG/faithnotes-ai/actions/workflows/lint.yml/badge.svg)](https://github.com/YOUR-GITHUB-ORG/faithnotes-ai/actions/workflows/lint.yml)
[![Build](https://github.com/YOUR-GITHUB-ORG/faithnotes-ai/actions/workflows/build.yml/badge.svg)](https://github.com/YOUR-GITHUB-ORG/faithnotes-ai/actions/workflows/build.yml)
[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)

This package lets you test FaithNotes AI on your **Android phone over your
home Wi-Fi**, instead of opening `faithnotes-ai.html` directly from
Downloads (`file://`) or a `content://` link — both of which the browser
blocks from ever requesting microphone access at all, no matter what you
tap "Allow" on.

It contains two small servers:

- **`dev-server/`** — serves the frontend (`public/faithnotes-ai.html`) over
  real HTTP/HTTPS on your local network. Zero npm dependencies.
- **`backend/`** — the FaithNotes API (auth, recording sync, logs). Same
  backend documented in `backend/README.md`, copied in here unchanged.

Plus **`start-all.js`**, which runs both together with one command.

---

## 1. One-time setup

```bash
# from this folder
cd backend
npm install
cp .env.example .env
```

Open `backend/.env` and set a real `JWT_SECRET`:

```bash
node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"
```

Paste that output as `JWT_SECRET=...` in `backend/.env`. The backend refuses
to start without this set to something real.

That's it — `dev-server/` has no dependencies to install.

---

## 2. Start everything

From this folder:

```bash
node start-all.js
```

You'll see both servers' logs, color-coded and labeled, in one terminal:

```
[frontend] ==========================================================
[frontend]  FaithNotes AI — Dev Server (HTTP)
[frontend] ==========================================================
[frontend]  Serving:  .../public
[frontend]  Local:    http://localhost:8080
[frontend]  Network:  http://192.168.1.100:8080   (Wi-Fi — use this from your phone)
[frontend] ==========================================================
[backend]  ==========================================================
[backend]   FaithNotes AI Backend
[backend]  ==========================================================
[backend]   Local:    http://localhost:3000
[backend]   Network:  http://<your-computer-ip>:3000   (use this from your phone)
[backend]  ==========================================================
```

Press **Ctrl+C** once to stop both cleanly.

Prefer separate terminals (easier to read each log on its own)? Skip
`start-all.js` and instead run:

```bash
# terminal 1
cd backend && npm start

# terminal 2
cd dev-server && npm start
```

Both approaches serve the exact same thing — `start-all.js` is just a
convenience wrapper around the same two commands.

---

## 3. Find your computer's LAN IP

The dev server prints it automatically on startup (the `Network:` line
above). If you need it separately:

- **Windows:** `ipconfig` → look for "IPv4 Address" under your Wi-Fi adapter
- **Mac:** `ipconfig getifaddr en0` (or `en1` if that's empty)
- **Linux:** `hostname -I`

Make sure your **phone and computer are on the same Wi-Fi network** —
this doesn't work across different networks (e.g., phone on cellular data).

---

## 4. Test on Android Chrome — step by step

1. On your computer, run `node start-all.js` (or the two servers separately) as above.
2. Note the `Network:` URL the dev server printed, e.g. `http://192.168.1.100:8080`.
3. On your Android phone, open **Chrome**.
4. Type that exact URL into the address bar and go. You should see the
   FaithNotes splash screen load — this confirms the phone can reach your
   computer.
5. In the app's **Settings → Backend Server**, enter your computer's backend
   URL, e.g. `http://192.168.1.100:3000`, and save. You should see "✓
   Connected" and a recording count.
6. Register an account and try recording.

**At this point, recording may fail with a microphone permission error —
this is expected on plain HTTP, and is a Chrome security policy, not a bug
in the app.** Read on.

---

## 5. Why microphone access needs HTTP→secure-context help on Android

Browsers only allow microphone access (`getUserMedia()`) on a **secure
context**: `https://`, or the special-cased `localhost`/`127.0.0.1`. A plain
`http://192.168.1.100:8080` — a real LAN IP over HTTP — does **not** count
as secure by default, even though it's private network traffic that never
leaves your Wi-Fi. This is a browser-level policy FaithNotes' own code
can't override; the app already detects this correctly and will tell you
clearly what's going on (see the Test Microphone page and the dashboard
banner) rather than showing a vague "permission denied."

You have two ways around it for local testing:

### Option A — Chrome flag (fastest, good for quick testing)

1. On your Android phone, open Chrome and go to:
   `chrome://flags/#unsafely-treat-insecure-origin-as-secure`
2. In the text box, enter the **exact** origin you're testing, including
   port, e.g.:
   ```
   http://192.168.1.100:8080
   ```
   (Comma-separate multiple origins if needed — e.g. if you also want to
   whitelist the backend's origin, though only the frontend's origin
   actually needs this, since microphone access is a property of the page
   you're on, not of where its `fetch()` calls go.)
3. Set the flag dropdown to **Enabled**.
4. Tap **Relaunch** at the bottom of the screen.
5. Re-open `http://192.168.1.100:8080` — the app will now report a secure
   context, and microphone access will work normally.

This flag only affects your own device and only the origins you list — it's
a standard, documented Chromium developer flag, not a hidden trick, but it
is a manual per-device setting you'll need to redo if you reset Chrome or
switch phones. It's meant for exactly this kind of local dev testing.

### Option B — Local HTTPS with mkcert (closer to production, more setup)

This makes the dev server serve real (locally-trusted) HTTPS, so you're
testing under the same kind of secure context production will actually use
— no flags needed on the phone, at the cost of a one-time certificate setup.

1. **Install mkcert** on your computer (not your phone):
   [github.com/FiloSottile/mkcert](https://github.com/FiloSottile/mkcert) —
   available via Homebrew (Mac), Chocolatey/Scoop (Windows), or your Linux
   package manager.
2. **Install mkcert's local CA:**
   ```bash
   mkcert -install
   ```
3. **Generate a cert for your computer's LAN IP** (use the same IP the dev
   server prints — this example uses `192.168.1.100`):
   ```bash
   cd dev-workflow/certs
   mkcert -cert-file cert.pem -key-file key.pem 192.168.1.100 localhost 127.0.0.1
   ```
   The dev server automatically detects `cert.pem`/`key.pem` in `certs/` and
   switches to HTTPS mode on next start — no config changes needed.
4. **Trust mkcert's root CA on your Android phone**, so Chrome there trusts
   the cert you just generated:
   - On your computer, run `mkcert -CAROOT` to find the CA file's folder —
     you want the file named `rootCA.pem` inside it.
   - Transfer `rootCA.pem` to your phone (email it to yourself, AirDrop/Nearby
     Share, USB transfer — whatever's easiest).
   - On Android: **Settings → Security → Encryption & credentials → Install
     a certificate → CA certificate** → select the transferred file → confirm
     the "install anyway" warning (this is expected; you generated this CA
     yourself, so it's trustworthy on devices you install it on).
5. Restart the dev server (`node dev-server/server.js`, or re-run
   `start-all.js`). It will now print `https://192.168.1.100:8080`.
6. Open that `https://` URL in Chrome on your phone. It should load with a
   trusted padlock, and microphone access will work with no flags.

If you'd rather skip installing a CA on your phone, a **tunnel service**
(ngrok, Cloudflare Tunnel) gives you real public HTTPS without any of this
— see `backend/README.md`'s "HTTPS for LAN testing" section for that
alternative, along with the tradeoffs (it goes over the internet, not just
your LAN, and requires an external account).

---

## 6. Production

None of the above applies once FaithNotes is actually deployed — a real
deployment behind a real domain with a certificate from a trusted CA
(Let's Encrypt, your host's built-in TLS, etc.) is automatically a secure
context everywhere, no flags or manual CA installs needed. This whole
section exists purely to unblock **local network testing** during
development. See `backend/README.md`'s "Production Deployment" section for
what changes when you actually ship this.

---

## 7. Troubleshooting

**Phone can't load the dev server URL at all (not a mic issue — nothing loads):**
- Confirm phone and computer are on the *same* Wi-Fi network (not phone on
  cellular, not a guest network that isolates devices from each other).
- Check your computer's firewall isn't blocking incoming connections on the
  dev server's port (8080) or the backend's port (3000).
- Some Wi-Fi routers/networks enable "client isolation" or "AP isolation,"
  which deliberately blocks devices on the same network from reaching each
  other — check your router's settings if this is a possibility.

**Page loads, but recording fails with a clear "can't access mic here" message:**
- That's the app correctly detecting an insecure context — see Section 5
  above. This isn't an app bug; it's the fix.

**Page loads, but recording fails with something else (device error, permission previously denied, etc.):**
- Open the app's **Test Microphone** page (Settings → Test Microphone) — it
  shows exactly which check is failing (browser support, HTTPS status,
  permission status, device detected) rather than a generic error.

**Backend shows "Not connected" in Settings even though it's running:**
- Double check the URL you entered matches exactly what the backend printed
  (including `http://` and the port), and that you're not accidentally
  pointing at the dev server's port (8080) instead of the backend's (3000)
  — they're two different servers.

---

## 8. Further documentation

- **`backend/README.md`** — the backend's own setup, API reference, and
  security notes (more detail than what's summarized here).
- **`TRANSCRIPTION.md`** — how live transcription, Whisper finalize,
  manual editing, and version history actually work.
- **`SERMON_ANALYSIS.md`** — the 9 AI analysis types and how they're
  generated.
- **`AI_FEATURES.md`** — the full picture on every AI integration point,
  including how the OpenAI API key is (and isn't) handled.
- **`SECURITY.md`** — what's actually implemented vs. known limitations.
- **`CHANGELOG.md`** — full development history.
- **`CONTRIBUTING.md`** — how to propose a change.

