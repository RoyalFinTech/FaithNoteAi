# Sermon Analysis

How FaithNotes AI generates the 9 types of AI analysis on the Sermon Detail
screen's "AI Analysis" tab. Implemented entirely client-side in
`public/faithnotes-ai.html` — there's no backend endpoint for this; the
browser calls OpenAI's Chat Completions API directly using the API key set
in Settings.

## The disclaimer comes first, deliberately

Every AI Analysis tab shows this banner above the content:

> 🤖 **AI-generated interpretation** — this content is written by ChatGPT
> based on the sermon transcript. It's a study aid, not part of the
> original sermon or Scripture itself. Always compare against the
> transcript and your own understanding of the passage.

This isn't decorative. The Transcript tab and the AI Analysis tab are
separate tabs specifically so the original sermon text and the AI's
interpretation of it are never visually merged into one block — a user
should always be able to tell which is which.

## The 9 analysis types

Defined in `ANALYSIS_PROMPTS` (search for that in the source). Each is a
separate system prompt sent to `gpt-4o-mini`:

| Tab | What it asks for |
|---|---|
| Summary | A short "Quick Summary" (2-3 sentences) + a "Detailed Summary" (one paragraph) |
| Main Theme | The single main theme, one sentence, then 2-3 sentences explaining it |
| Key Points | 5-8 bullet points |
| Prayer Points | 5-7 short, heartfelt prayer points |
| Reflection Questions | 5 personal reflection questions |
| Action Steps | 5 practical steps for the coming week |
| Bible Study Guide | An opening question, 3-4 scripture-based discussion points, a closing prayer prompt |
| Youth Discussion Guide | 4-5 simple-language discussion questions + one weekly challenge |
| Small Group Discussion | 6 discussion questions for a home fellowship setting |

Every prompt explicitly includes the sermon's detected Bible verse
references (see `TRANSCRIPTION.md`) alongside the transcript, so the model
has that context even where the transcript's spoken wording of a reference
might be garbled.

## How generation actually works

1. Tapping a tab calls `renderAnalysisTab(tabKey)`.
2. If that tab's content is already cached on the sermon object
   (`sermon.analysis[tabKey]`), it's shown immediately — **no new API
   call**. Each type is generated once and reused until you explicitly
   regenerate it.
3. If there's no API key set, the tab shows a lock icon and a prompt to
   add one in Settings — it does not silently fail or show an error as if
   something broke.
4. Otherwise, it calls `openaiChat()` with the system prompt (see table
   above) plus a user message containing the sermon title, preacher, the
   detected verse list, and up to the first ~12,000 characters of the
   transcript (a practical limit to keep requests reasonably sized — very
   long sermons may have their analysis based on a truncated transcript).
5. The raw markdown-ish text response is rendered through
   `simpleMarkdown()`, which escapes HTML *before* applying any formatting
   — this is a deliberate security choice, not just style (see
   `AI_FEATURES.md` → "Why responses are escaped before formatting").
6. The result is cached on `sermon.analysis[tabKey]` and persisted to
   `localStorage` — re-opening the sermon later shows the same content
   without another API call, until you tap "↻ Regenerate."

## Cost and privacy notes worth knowing

- Every tab you generate is a separate OpenAI API call, billed to whatever
  API key you've configured — there is no server-side proxy, rate
  limiting, or cost control on this path (see `AI_FEATURES.md` for the
  full picture on how the API key is handled).
- The sermon transcript (up to ~12,000 characters) is sent to OpenAI as
  part of every generation request for that sermon. If a transcript
  contains anything sensitive that was spoken during the sermon, that
  content leaves the device as part of this request.
- Regenerating a tab overwrites the cached content for that tab — there's
  no history/versioning for AI analysis the way there is for the
  transcript itself (see `TRANSCRIPTION.md`).

## What isn't implemented

- No streaming — the "Generating with ChatGPT…" spinner shows until the
  full response arrives; text doesn't appear incrementally.
- No per-sermon model choice — `gpt-4o-mini` is hardcoded.
- No cross-sermon analysis ("summarize this preacher's last 5 sermons") —
  each analysis type only ever sees one sermon's transcript.
