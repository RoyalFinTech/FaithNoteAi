# Transcription

How FaithNotes AI turns recorded audio into a transcript, and what happens
to that transcript afterward. This describes the actual implementation in
`public/faithnotes-ai.html` — there's no separate transcription service or
backend endpoint; it's all client-side.

## Two transcription paths

### 1. Live transcription (free, real-time, browser-native)

While recording, `startLiveTranscription()` uses the browser's built-in
`SpeechRecognition` API (`webkitSpeechRecognition` on Chrome/Edge/Safari).
This is:

- **Free** — no API key, no network request, no cost.
- **Real-time** — text appears as the sermon is being preached, shown live
  in the recording studio.
- **Best-effort** — accuracy varies by browser, accent, audio quality, and
  background noise. It's also not universally supported: Firefox doesn't
  implement it at all, in which case the app shows a clear message
  ("Live transcription isn't supported in this browser...") and continues
  recording audio normally — the *recording* never depends on live
  transcription succeeding.
- Restarts itself automatically if the browser's recognition engine times
  out mid-recording (a known browser quirk, handled in
  `recognition.onend`).

This is what gets saved as the sermon's initial `transcript` the moment
recording stops.

### 2. Whisper finalize (paid, on-demand, higher accuracy)

On the Sermon Detail screen's Transcript tab, a **"✨ Finalize with Whisper
AI"** button calls `whisperFinalize()`, which sends the recorded audio file
to OpenAI's Whisper API (`whisperTranscribe()`) using the API key you've
set in Settings. This:

- Costs money (OpenAI API usage) and requires an internet connection.
- Generally produces a more accurate transcript than live
  `SpeechRecognition`, especially for accents or audio quality the
  browser's engine struggled with.
- **Replaces** the existing transcript — but not destructively. See
  "Version history" below.
- Re-runs Bible verse detection against the new text (since a more
  accurate transcript may catch references the live transcription missed
  or garbled).

The button only appears if the sermon actually has audio available
(`sermon.audioURL` or `sermon.audioStoredLocally`) — there's nothing to
re-transcribe otherwise. Audio is rehydrated from IndexedDB first if the
in-memory `blob:` URL died on a page reload (see `ensureSermonAudioURL()`).

## Manual editing

The transcript is editable. Tapping **"✏️ Edit Transcript"** swaps the
read-only display for a `<textarea>`; edits autosave 1.5 seconds after you
stop typing (`scheduleTranscriptAutosave()` → `saveTranscriptEdit()`), and
also save immediately when you tap "✓ Done Editing".

Editing re-runs Bible verse detection on the edited text — if you fix a
misheard reference or add one the auto-detector missed, it's picked up
immediately.

## Version history

Every time the transcript changes — through a manual edit *or* a Whisper
finalize — the previous version is pushed onto `sermon.transcriptHistory`
(capped at the last 10 versions, oldest dropped first). This means:

- A Whisper re-transcription never silently destroys a manual edit you
  made earlier — the edit is still there, one "Restore previous version"
  tap away.
- The Transcript tab shows a small "`N` earlier version(s) saved" note and
  a restore link whenever history exists.

This history is **not** a full diff/audit trail — it stores whole-text
snapshots, not deltas, and only the most recent 10. It's meant for "I want
my last version back," not for reviewing every incremental change.

## Bible verse detection over the transcript

Every time the transcript is set (initial recording, Whisper finalize, or
a manual edit), `detectBibleVerses()` runs a regex scan for book/chapter/verse
patterns against the full list of Bible books. See `AI_FEATURES.md` for how
detected verses feed into AI analysis, and the transcript itself highlights
each detected reference inline (clickable, jumps to the Bible Verses tab) —
see `renderTranscript()`.

## What isn't implemented

- **Speaker diarization / speaker timestamps.** Neither the browser's
  `SpeechRecognition` API nor the specific Whisper endpoint this app calls
  (`audio/transcriptions`, not the verbose/segment-timestamped variant)
  provide per-speaker labels. A sermon transcript is treated as one
  continuous block of text from one speaker.
- **Per-word confidence scores.** Chrome's `SpeechRecognition` does expose
  a `confidence` value per result internally, but the app doesn't currently
  surface it in the UI. This would be a reasonable future addition, but
  isn't there today — don't assume a "confidence indicator" exists.
- **Paragraph auto-formatting.** The transcript is stored and displayed as
  the browser/Whisper API returned it. Whisper's plain-text endpoint
  doesn't add paragraph breaks on its own, and this app doesn't
  post-process the text to add them.
