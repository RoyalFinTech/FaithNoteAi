# AI Features

Every place FaithNotes AI touches an AI provider, how it's wired, and what
that actually means for cost, privacy, and reliability. This is the
overview document — see `SERMON_ANALYSIS.md` for the 9 analysis types in
detail and `TRANSCRIPTION.md` for the two transcription paths.

## There is no AI backend

All three AI integrations below call OpenAI's API **directly from the
browser**, using `fetch()`. There is no `/api/ai/*` route, no server-side
proxy, and no backend involvement at all — the Node/Express backend
(`backend/`) only handles auth, recording storage, and sync; it has no
knowledge of or role in any AI request.

This is a deliberate architectural choice with real tradeoffs:

**What this means for you:**
- Your OpenAI API key lives only in `localStorage` on your device (see
  `getApiKey()`/`saveApiKey()`) and is sent directly to `api.openai.com` —
  it never passes through the FaithNotes backend. The backend genuinely
  cannot see it, log it, or be a point of failure for it.
- There's no server-side cost control, rate limiting, or usage tracking on
  AI calls. Every generation is billed directly to your own OpenAI account
  at whatever OpenAI's own rate limits allow.
- If you don't set an API key, every AI feature below degrades gracefully
  — a clear prompt to add one in Settings, not a broken UI or a silent
  failure.

## The three integration points

### 1. Sermon Analysis (9 types)
`gpt-4o-mini`, one system prompt per analysis type, transcript + detected
verses as context. See `SERMON_ANALYSIS.md` for the full breakdown.

### 2. AI Chat Assistant
Reachable per-sermon (context-aware, knows that sermon's transcript and
verses) or as a general chat (knows a summary of your recent sermon
library — title, preacher, date, detected verses for up to 10 sermons).
Implemented in `sendChat()`. Like sermon analysis, this is `gpt-4o-mini`
via the same `openaiChat()` helper, with the last 10 messages of
conversation history included for continuity. Chat history is stored
per-sermon (or under a `'general'` key) in `STATE.chats` and persisted
locally — it is never sent anywhere except as context for that
conversation's own next request.

### 3. Whisper Transcription (finalize)
`whisper-1` via OpenAI's `/v1/audio/transcriptions` endpoint, sending the
actual recorded audio file. See `TRANSCRIPTION.md`.

## Why responses are escaped before formatting

Every AI response — sermon analysis and chat replies alike — is rendered
through `simpleMarkdown()`, which runs `escapeHTML()` **first**, before any
markdown-to-HTML conversion. This means even if a transcript (and
therefore the AI's response, which is built from that transcript) somehow
contained something that looked like an HTML tag or script content, it
would already be neutralized to inert text before the formatting step ever
touches it — the formatting step only ever introduces a small, fixed set
of safe tags (`<h5>`, `<b>`, `<li>`, `<ul>`, `<br>`) that it controls
itself, never anything derived from the AI's actual output. This was
specifically verified during a security audit of this codebase (checked
every render path that interpolates AI or user content into `innerHTML`).

## Bible verses are detected by regex, not AI

Worth being explicit about, since it's easy to assume otherwise: the Bible
verse references shown throughout the app (Bible Verses tab, transcript
highlighting, the Verse Library) come from `detectBibleVerses()` — a plain
JavaScript regex scan against a hardcoded list of Bible book names. No AI
model is involved in detecting *which* verses were mentioned. AI only gets
involved afterward, when generating analysis that *references* those
already-detected verses, or when fetching the actual verse *text* for a
detected reference (via the free `bible-api.com` service for KJV — also
not an AI call, just a lookup).

## What isn't implemented

- No AI provider other than OpenAI — no Anthropic, no local/open-source
  model option, no provider fallback if OpenAI is down or the key is
  invalid beyond a clear error message.
- No usage/cost dashboard — you'd need to check your OpenAI account
  directly to see what you've spent.
- No content moderation layer of FaithNotes' own — you're relying on
  whatever OpenAI's own usage policies and moderation already provide.
- No offline AI — every one of these three features requires a live
  internet connection and a valid API key; there's no local fallback
  model.
