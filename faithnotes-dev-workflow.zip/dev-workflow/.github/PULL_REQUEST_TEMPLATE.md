## What does this change?

<!-- A clear, concise description of what this PR does and why. -->

## Type of change

- [ ] Bug fix
- [ ] New feature
- [ ] Documentation
- [ ] Tooling / CI / dev workflow
- [ ] Other (describe above)

## How was this tested?

<!--
There is currently no automated test suite (see CHANGELOG.md and
SECURITY.md "Known limitations") — until one exists, please describe
concretely what you did to verify this change:
- Which commands you ran (npm run lint:all, manual endpoint tests, etc.)
- What you clicked through in the browser, and on what device/browser
- What you expected to see vs. what you actually saw
-->

## Checklist

- [ ] `npm run lint:all` passes
- [ ] I manually verified this change works (see "How was this tested?" above)
- [ ] I updated the README if setup/usage steps changed
- [ ] I updated `.env.example` if I added a new environment variable
- [ ] I did not commit any secrets, API keys, or `.env` files
