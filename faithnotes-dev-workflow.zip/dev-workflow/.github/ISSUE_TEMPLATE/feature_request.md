---
name: Feature request
about: Suggest an idea or improvement
title: "[Feature] "
labels: enhancement
---

**What problem would this solve?**
A clear description of the problem or gap you've noticed.

**Describe the solution you'd like**

**Describe alternatives you've considered**

**Additional context**
Note whether this affects the frontend (`public/faithnotes-ai.html`), the
backend (`backend/`), or the local dev workflow (`dev-server/`,
`start-all.js`) — that helps route the request appropriately.
