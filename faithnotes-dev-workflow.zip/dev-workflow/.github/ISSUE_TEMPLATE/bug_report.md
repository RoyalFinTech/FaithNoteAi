---
name: Bug report
about: Report something that isn't working correctly
title: "[Bug] "
labels: bug
---

**What happened?**
A clear description of the bug.

**What did you expect to happen?**

**Steps to reproduce**
1.
2.
3.

**Environment**
- Component: [frontend / backend / dev-server]
- OS:
- Node version (if backend/dev-server): `node --version`
- Browser + version (if frontend):
- Device (if mobile/Android-specific):

**Logs / console output**
Paste any relevant output — browser console (look for `[Faithnotes:*]`
prefixed messages), or backend terminal output.

**Additional context**
Anything else that might help — screenshots, whether this happens
consistently or intermittently, etc.
